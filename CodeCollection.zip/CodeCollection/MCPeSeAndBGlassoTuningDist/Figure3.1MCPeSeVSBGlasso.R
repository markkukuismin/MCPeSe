
# 7.7.2020

# Compare the posterior distribution of the tuning parameter estimated with MCPeSe
# with the full Bayesian model

library(huge)
library(ggplot2)
library(grid)
library(gridExtra)
library(MASS)
library(BayesianGLasso)

source("../RFunctions/mcpese.R")

##########################################################

# Graphical model simulation:

Model = "random"

##########################################################

p = 100 # Nmb of variables/network nodes

nrho = 100 # The number of tuning parameters used in mcpese

n = 200 # The sample size

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 22705

set.seed(seed)

##########################################################

# Simulate toy data:

HugeData = huge.generator(n=n, d=p, graph=Model) 

Y = HugeData$data

Y = scale(Y)

##########################################################

# Bayes Glasso uses, gamma prior with shape parameter = 1, scale parameter = 1/10

burnIn = 500 # Bayes Glasso burn-in

MCMClength = 2000 # Length of Markov chain after burn-in

BGlassoMCMC = blockGLasso(Y, iterations = MCMClength, burnIn = burnIn)

##########################################################

# Define rho for Glasso from the posterior values of the BGlasso

nrho = 100

rho = tail(BGlassoMCMC$lambdas, MCMClength)

rho = sort(rho, decreasing = T)

rho = rho[seq(1, MCMClength, length.out = nrho)]/n

FullBayesrhoInd = match(rho, BGlassoMCMC$lambdas/n)

# Then, run the frequentist Glasso using huge:

GlassoSolPath = huge(Y, lambda=rho, method="glasso")

##########################################################

# Estimate the posterior distribution using the Metropolis-Hastings algorithm:

# The algorithm uses the same gamma prior hyperparameters as the 
# BGlasso

MCPeSeEstimate = mcpese(GlassoSolPath, n=nrow(Y), nSteps = 10^5, 
                        method="M-H", prior="gamma", MH.sampling = "unif")


##########################################################

# Inspect the posterior distributions of the tuning parameter:

MCPeSerho = MCPeSeEstimate$rhos # MCPeSe discards the burn-in 

FullBayesLambda = BGlassoMCMC$lambdas # Full Bayes model tuning parameters

FullBayesLambda = tail(FullBayesLambda, MCMClength) # Discard the burn-in

FullBayesrho = FullBayesLambda/n # lambda = n*rho

##########################################################

# Plot the posterior distributions:

TuningParamPostMCPeSe = table(round(MCPeSerho, 3))

TuningParamPostMCPeSe = data.frame(rho = as.numeric(names(TuningParamPostMCPeSe)), 
                                  Prob = as.vector(TuningParamPostMCPeSe)/length(MCPeSerho))

Fig1 = ggplot(TuningParamPostMCPeSe, aes(x = rho, y = Prob)) + 
  geom_col(colour="black", fill="white", position="stack") +
  #xlab("Tuning parameter value") +
  ylab("Probability") +
  theme(axis.title.x = element_blank(),
        axis.text.x = element_text(size=7, angle = 45, hjust=1),
        axis.text.y = element_text(size=7),
        axis.title.y = element_text(face="bold")) +
  scale_x_continuous(labels = scales::number_format(accuracy = 0.001)) + 
  geom_vline(xintercept = mean(FullBayesrho), color="red", 
             linetype = "dashed", size=1.2) +
  geom_vline(xintercept = mean(MCPeSerho),
             color="blue", linetype="dashed", size=1.2)

TuningParamPostFullBayes = data.frame(rho = FullBayesrho)

Fig2 = ggplot(TuningParamPostFullBayes, aes(x = rho)) + 
  geom_histogram(color="black", fill="white", aes(y=..density..)) +
  #xlab("Tuning parameter value") +
  ylab("Density") +
  theme(axis.title.x = element_blank(),
        axis.text.x = element_text(size=7, angle = 45, hjust = 1),
        axis.text.y = element_text(size=7),
        axis.title.y = element_text(face="bold")) +
  scale_x_continuous(labels = scales::number_format(accuracy = 0.001)) + 
  geom_vline(xintercept = mean(FullBayesrho),
             color="red", linetype="dashed", size=1.2) +
  geom_vline(xintercept = mean(MCPeSerho),
             color="blue", linetype="dashed", size=1.2)

TuningParamsMCPeSe = data.frame(rho = MCPeSerho)

Fig3 = ggplot(TuningParamsMCPeSe, aes(x = rho)) + 
  geom_histogram(color="black", fill="white", aes(y=..density..)) +
  #xlab("Tuning parameter value") +
  ylab("Density") +
  theme(axis.title.x = element_blank(),
        axis.text.x = element_text(size=7, angle = 45, hjust = 1),
        axis.text.y = element_text(size=7),
        axis.title.y = element_text(face="bold")) +
  scale_x_continuous(labels = scales::number_format(accuracy = 0.001)) + 
  geom_vline(xintercept = mean(FullBayesrho),
             color="red", linetype="dashed", size=1.2) +
  geom_vline(xintercept = mean(MCPeSerho),
             color="blue", linetype="dashed", size=1.2)

Fig1 = Fig1 + ggtitle("Posterior distribution (MCPeSe)") + 
  theme(plot.title = element_text(size = 10, face = "bold")) +
  theme(plot.title = element_text(hjust = 0.5))

Fig2 = Fig2 + ggtitle("Posterior distribution (BGlasso)") + 
  theme(plot.title = element_text(size = 10, face = "bold")) +
  theme(plot.title = element_text(hjust = 0.5))
  
Fig3 = Fig3 + ggtitle("Posterior distribution (MCPeSe)") + 
  theme(plot.title = element_text(size = 10, face = "bold")) +
  theme(plot.title = element_text(hjust = 0.5))

Fig1 = Fig1 + labs(tag = "(A1)") + theme(plot.tag = element_text(size = 8))

Fig3 = Fig3 + labs(tag = "(A1)") + theme(plot.tag = element_text(size = 8))

Fig2 = Fig2 + labs(tag = "(A2)") + theme(plot.tag = element_text(size = 8))

grid.arrange(arrangeGrob(Fig1 + theme(legend.position="none"),
                         Fig2 + theme(legend.position="none"),
                         ncol = 2,
                         bottom = textGrob("Tuning parameter value", vjust=-0.3, gp=gpar(fontface="bold"))),nrow=1)

grid.arrange(arrangeGrob(Fig3 + theme(legend.position="none"),
                         Fig2 + theme(legend.position="none"),
                         ncol = 2,
                         bottom = textGrob("Tuning parameter value", vjust=-0.3, gp=gpar(fontface="bold"))),nrow=1)

scale= 0.9

cairo_ps("Figure3.1.eps", width = 7*scale, height = 3.4*scale, onefile = T, fallback_resolution = 600)

grid.arrange(arrangeGrob(Fig1 + theme(legend.position="none"),
                         Fig2 + theme(legend.position="none"),
                         ncol = 2,
                         bottom = textGrob("Tuning parameter value", vjust=-0.3, gp=gpar(fontface="bold"))),nrow=1)

dev.off()

#####################################################

cairo_ps("Figure3.2.eps", width = 7*scale, height = 3.4*scale, onefile = T, fallback_resolution = 600)

grid.arrange(arrangeGrob(Fig3 + theme(legend.position="none"),
                         Fig2 + theme(legend.position="none"),
                         ncol = 2,
                         bottom = textGrob("Tuning parameter value", vjust=-0.3, gp=gpar(fontface="bold"))),nrow=1)

dev.off()
