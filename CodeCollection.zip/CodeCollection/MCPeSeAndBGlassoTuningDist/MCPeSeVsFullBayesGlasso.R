
# 7.7.2020

# Compare the posterior distribution of the tuning parameter estimated with MCPeSe
# with the full Bayesian model

library(huge)
library(glasso)
library(MASS)
library(BayesianGLasso)

source("../RFunctions/mcpese.R")

##########################################################

# Graphical model simulation:

Model = "random"

##########################################################

p = 100 # Nmb of variables/network nodes

nrho = 100 # The number of tuning parameters used in mcpese

n = 200 # The sample size

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 22705

set.seed(seed)

##########################################################

# Simulate toy data:

HugeData = huge.generator(n=n, d=p, graph=Model) 

Y = HugeData$data

Y = scale(Y)

##########################################################

# Bayes Glasso uses, gamma prior with shape parameter = 1, scale parameter = 1/10

burnIn = 500 # Bayes Glasso burn-in

MCMClength = 2000 # Length of Markov chain after burn-in

BGlassoMCMC = blockGLasso(Y, iterations = MCMClength, burnIn = burnIn)

##########################################################

# Define rho for Glasso from the posterior values of the BGlasso

nrho = 100

rho = tail(BGlassoMCMC$lambdas, MCMClength)

rho = sort(rho, decreasing = T)

rho = rho[seq(1, MCMClength, length.out = nrho)]/n

FullBayesrhoInd = match(rho, BGlassoMCMC$lambdas/n)

# Then, run the frequentist Glasso using huge:

GlassoSolPath = huge(Y, lambda=rho, method="glasso")

##########################################################

# Estimate the posterior distribution using the Metropolis-Hastings algorithm:

# The algorithm uses the same gamma prior hyperparameters as the 
# BGlasso

MCPeSeEstimate = mcpese(GlassoSolPath, n=nrow(Y), nSteps = 10^5, 
                        method="M-H", prior="gamma", MH.sampling = "unif")


##########################################################

# Inspect the posterior distributions of the tuning parameter:

MCPeSerho = MCPeSeEstimate$rhos # MCPeSe discards the burn-in 

FullBayesLambda = BGlassoMCMC$lambdas # Full Bayes model tuning parameters

FullBayesLambda = tail(FullBayesLambda, MCMClength) # Discard the burn-in

FullBayesrho = FullBayesLambda/n # lambda = n*rho

# Compute the posterior mean of the full Bayesian tuning parameter distribution

MeanFullBayesrho = mean(FullBayesrho)

# Determine the posterior probabilities of the tuning parameter posterior values
# estimated with mcpese:

MCPeSeProb = table(round(MCPeSerho, 3))

MCPeSeProb = MCPeSeProb/sum(MCPeSeProb)

# Compute the posterior mean estimate of mcpese:

MeanMCPeSerho = mean(MCPeSerho)

# Determine help parameters needed in the barplot:

BarplotRefLineFullBayes = which.min(
  abs(as.numeric(names(MCPeSeProb)) - MeanFullBayesrho))

BarplotRefLineMCPeSe = which.min(
  abs(as.numeric(names(MCPeSeProb)) - MeanMCPeSerho))

##########################################################

# Plot the posterior distributions:

png('Figure1_histogram.png', width = 630, height = 350)

par(mfrow = c(1, 2))

hist(MCPeSerho, xlab="rho", main="rho post. MCPeSe", probability = T)

abline(v=MeanFullBayesrho, col="red", lty=2, lwd=2) # Full Bayes rho mean

abline(v=MeanMCPeSerho, col="blue", lty=2, lwd=2) # MCPeSe rho mean

hist(FullBayesrho, main="rho post. full Bayes", xlab="rho", probability = T)

abline(v = MeanFullBayesrho, col="red", lty=2, lwd=2) # The full Bayes rho mean

abline(v = MeanMCPeSerho, col="blue", lty=2, lwd=2) # MCPeSe rho mean

dev.off()

png("Figure1_barplot.png", width = 630, height = 350)

par(mfrow = c(1, 2))

barplot(MCPeSeProb, xlab="rho", ylab="Probability")

title("rho post. probab. MCPeSe")

# The vertical lines are little of in the barplot figure...

abline(v=BarplotRefLineFullBayes, col="red", lty=2, lwd=2) # Full Bayes rho mean

abline(v=BarplotRefLineMCPeSe, col="blue", lty=2, lwd=2) # MCPeSe rho mean

hist(FullBayesrho, main="rho post. full Bayes", xlab="rho", probability = T)

abline(v = MeanFullBayesrho, col="red", lty=2, lwd=2) # The full Bayes rho mean

abline(v = MeanMCPeSerho, col="blue", lty=2, lwd=2) # MCPeSe rho mean

dev.off()

# As one can see, these posterior distributions are very similar, although
# the precision matrices parameters computed with BGlasso are different
# (in particular, non-sparse matrices).

# We illustrate the difference between precision matrices with
# the Frobenius norm. In addition, we use an alternative algorithm to compute
# the Glasso estimates (package "glasso"):

FGlasso = lapply(GlassoSolPath$icov, function(x) norm(x, type="F"))

FGlasso = unlist(FGlasso) # The Frobenius norm of the Glasso precision matrices
# computed with huge

# Compute the frequentist estimates of the precision matrix using alternative
# algorithm implemented in the 

D = glassopath(cov(Y), rho=rho, trace = 0) # cor(Y) or cov(Y), it does not make 
# a difference in the final result because the data is standardized 

FGlassoAlt = rep(0, nrho) # The Frobenius norm of the alternative Glasso algorithm

for(i in 1:nrho){
  
  FGlassoAlt[i] = norm(D$wi[i, , ], type = "F")
  
}

FBGlasso = lapply(BGlassoMCMC$Omegas[FullBayesrhoInd], 
                  function(x) norm(x, type="F"))

FBGlasso = unlist(FBGlasso) # The Frobenius norm of the BGlasso precision matrices

png("Figure2_Fnorm.png", width = 630, height = 350)

par(mfrow=c(1, 1))

plot(rho, FGlasso, type="b", 
     ylim=c(min(c(FGlasso, FBGlasso, FGlassoAlt)), 
            max(c(FGlasso, FBGlasso, FGlassoAlt))), 
     ylab="Frobenius norm")

lines(rho, FBGlasso, type="b", col="red") # Red line is the Bayes Glasso

lines(rho, FGlassoAlt, col="blue", type = "b") # blue line is the alternative
# Glasso algorithm

dev.off()

##########################################################

# The posterior computed with the "default" setting of the huge package 
# is totally different because the support of the tuning parameter is
# totally different:

GlassoSolPathAlt = huge(Y, nlambda = nrho, method="glasso")

# Estimate the posterior distribution using the Metropolis-Hastings algorithm:

# The algorithm uses the same gamma prior hyperparameters as the 
# BGlasso

MCPeSeEstimateAlt = mcpese(GlassoSolPathAlt, n=nrow(Y), nSteps = 10^5, 
                        method="M-H", prior="gamma", MH.sampling = "unif")

MCPeSerhoAlt = MCPeSeEstimateAlt$rhos # MCPeSe discards the burn-in 

# Compute the posterior mean estimate of mcpese when different tuning parameter values are used:

MeanMCPeSerhoAlt = mean(MCPeSerhoAlt)

##########################################################

# Plot the posterior distributions:

png('Figure1_histogramAlternativeTuningValues.png', width = 630, height = 350)

par(mfrow = c(1, 2))

hist(MCPeSerhoAlt, xlab="rho", main="rho post. MCPeSe", probability = T)

abline(v=MeanFullBayesrho, col="red", lty=2, lwd=2) # Full Bayes rho mean

abline(v=MeanMCPeSerhoAlt, col="blue", lty=2, lwd=2) # MCPeSe rho mean (alternative)

hist(FullBayesrho, main="rho post. full Bayes", xlab="rho", probability = T)

abline(v = MeanFullBayesrho, col="red", lty=2, lwd=2) # The full Bayes rho mean

abline(v = MeanMCPeSerhoAlt, col="blue", lty=2, lwd=2) # MCPeSe rho mean

dev.off()

##########################################################

# Let's try something different: Choose values of the tuning parameter and 
# the precision matrix from the BGlasso solution path and use them as the input
# in mcpese

# First, choose tuning parameter values which cover the posterior distribution
# under the fully Bayesian model:

DummyLambda = tail(BGlassoMCMC$lambdas, MCMClength)

DummyLambda = sort(DummyLambda, decreasing = T)

DummyLambda = DummyLambda[seq(1, MCMClength, length.out = nrho)]

Dummyrho = DummyLambda/n

#abline(v=DummyLambda/n, lty=2)

# Choose the corresponding precision matrices:

FullBayesInd = match(DummyLambda, BGlassoMCMC$lambdas)

DummySolPath = GlassoSolPath

DummySolPath$icov = BGlassoMCMC$Omegas[FullBayesInd]

DummySolPath$lambda = Dummyrho

##########################################################

# Now, estimate the posterior distribution with mcpese using just
# a few values from the solution path of BGlasso:

DummyMCPeSeEstimate = mcpese(DummySolPath, n=nrow(Y), nSteps = 5*10^4,
                             method="M-H", prior="gamma", 
                             MH.sampling = "unif")

# Pick the posterior tuning parameter values:

DummyMCPeSerho = DummyMCPeSeEstimate$rhos

DummyMCPeSeLambda = DummyMCPeSerho*n

##########################################################

# Plot the histogram of rho, which is the tuning parameter of the
# fully Bayes model

MeanFullBayesLambda = mean(FullBayesLambda)

png("Figure3_lambda.png", width=630, height=350)

par(mfrow=c(1, 2))

d = hist(DummyMCPeSeLambda, main="lambda post. MCPeSe", 
         probability = T, xlab="lambda")

abline(v=MeanFullBayesLambda, col="red", lwd=2, lty=2) # Mean of the BGlasso lambda

hist(FullBayesLambda, main="lambda post. full Bayes", probability = T,
     breaks = d$breaks, xlab="lambda")

abline(v=MeanFullBayesLambda, col="red", lwd=2, lty=2) # Mean of the BGlasso lambda

dev.off()

##########################################################

# Plot the posterior probabilities and distributions of rho:

DummyMCPeSeProb = table(round(DummyMCPeSerho, 3))

DummyMCPeSeProb = DummyMCPeSeProb/sum(DummyMCPeSeProb)

# Compute the posterior mean estimate of mcpese:

DummyMeanMCPeSerho = mean(DummyMCPeSerho)

# Determine help parameters needed in the barplot:

BarplotRefLineFullBayes = which.min(
  abs(as.numeric(names(DummyMCPeSeProb)) - MeanFullBayesrho))

BarplotRefLineMCPeSe = which.min(
  abs(as.numeric(names(DummyMCPeSeProb)) - DummyMeanMCPeSerho))

png('Figure4_rho.png', width=630, height = 350)

par(mfrow = c(1, 2))

barplot(DummyMCPeSeProb, xlab="rho", ylab="Probability")

title("rho post. probab. MCPeSe")

abline(v=BarplotRefLineFullBayes, col="red", lty=1, lwd=2) # Full Bayes rho mean

abline(v=BarplotRefLineMCPeSe, col="blue", lty=2, lwd=2) # MCPeSe rho mean 
# estimated from the BGlasso solution path

hist(FullBayesrho, main="rho post. full Bayes", probability = T, xlab="rho")

abline(v = MeanFullBayesrho, col="red", lty=2, lwd=2) # The full Bayes rho mean

abline(v = DummyMeanMCPeSerho, col="blue", lty=2, lwd=2) # MCPeSe rho mean 
# estimated from the BGlasso solution path

dev.off()

# The posterior of rho estimated with MCPeSe is quite close to the posterior mean
# of the fully Bayesian model:

abs(mean(DummyMCPeSeLambda)/n - MeanFullBayesrho)

##########################################################

# How about compute a shorter MCMC chain with the fully Bayesian model?

ShortBGlassoMCMC = blockGLasso(Y, iterations = 200, burnIn = 100)

ShortSolPath = GlassoSolPath

ShortSolPath$lambda = sort(
  tail(ShortBGlassoMCMC$lambda, 200), decreasing = T)/n

d = order(tail(ShortBGlassoMCMC$lambda, 200))

ShortSolPath$icov = ShortBGlassoMCMC$Omegas[d]

ShortMCPeSeEstimate = mcpese(ShortSolPath, n=nrow(Y), nSteps = 5*10^4,
                             method="M-H", prior="gamma", 
                             MH.sampling = "unif")

# Plot the results:

par(mfrow=c(1, 2))

d = hist(ShortMCPeSeEstimate$rhos, main="rho post. MCPeSe", probability = T)

# How does this compare to the full Bayes rho mean computed from a short
# MCMC chain

abline(v=MeanFullBayesrho, col="red", lwd=2, lty=2)

hist(ShortBGlassoMCMC$lambdas/n, main="rho post. full Bayes", probability = T,
     breaks = length(d$breaks))

abline(v=MeanFullBayesrho, col="red", lwd=2, lty=2) # Mean of the BGlasso

# How does this compare to the full Bayes rho mean computed from a longer 
# MCMC chain:

par(mfrow=c(1, 2))

d = hist(ShortMCPeSeEstimate$rhos, main="rho post. MCPeSe", probability = T)

abline(v=MeanFullBayesrho, col="red", lwd=2, lty=2)

hist(FullBayesrho, main="rho post. full Bayes", probability = T,
     breaks = length(d$breaks))

abline(v=MeanFullBayesrho, col="red", lwd=2, lty=2) # Mean of the BGlasso

# The posterior distribution estimate is "smoother" but the posterior mean
# is estimated quite accurately:

abs(mean(ShortBGlassoMCMC$lambdas)/n - MeanFullBayesrho)

abs(mean(ShortMCPeSeEstimate$rhos) - MeanFullBayesrho)
