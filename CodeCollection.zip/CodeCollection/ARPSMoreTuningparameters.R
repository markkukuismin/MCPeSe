
# 19.12.2019

# Use the following version of huge

cat("library(huge)",
    sep="\n",
    file="checkpoint_packages_code.R")


library(checkpoint)

checkpoint("2019-11-24")

# How consistent are the results when tuning parameter is selected using Accept-Reject-type algorithm
# in high-dimensions:

library(MASS)
library(huge)

source("RFunctions/SpSeFallPreMCC.txt")
source("RFunctions/ARPS.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 86885

set.seed(seed)

##########################################################

# The graphical model

Model = "scale-free"

p = 250

##########################################################

Simrounds = 50

nrhos = c(50, 100, 150, 200, 250) # Different nmb of tuning parameters

BestSp   = matrix(0, Simrounds, length(nrhos))
BestSen  = matrix(0, Simrounds, length(nrhos)) 
BestFall = matrix(0, Simrounds, length(nrhos))
BestPre  = matrix(0, Simrounds, length(nrhos))
BestMCC  = matrix(0, Simrounds, length(nrhos))

AcceptRate = matrix(0, Simrounds, length(nrhos))

ARPSResults = array(0, c(Simrounds, 5, length(nrhos)))

colnames(ARPSResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

BestResults = ARPSResults

##########################################################

for(R in 1:length(nrhos)){
  
  # Graphical model simulation:
  
  nrho = nrhos[R]
  
  HugeData = huge.generator(n=10, d=p, graph=Model) # Just the precision matrix corresponding to the graphical model of
  # interest is needed. Data is simulated later.
  
  Sigma = HugeData$sigma
  
  n = floor(p/2) # This is more or less an arbitrary proportion.
  
  for(si in 1:Simrounds){
    
    Y = mvrnorm(n, rep(0,p), Sigma)
    
    # Use tuning parameter values on a non-log scale:
    
    Y = scale(Y)
    S = cor(Y)
    
    lambda.min.ratio = 0.1
    lambdamax = max(max(S - diag(p)), -min(S - diag(p)))
    lambdamin = lambda.min.ratio * lambdamax
    lambda = seq(lambdamax, lambdamin, length = nrho)
    
    L = huge(Y, lambda=lambda, method="glasso")
    
    ##########################################################
    
    # Accept-reject algorithm:
    
    ARSelect = ARPS(L, n=nrow(Y))
    
    rhos = ARSelect$rhos
    
    AcceptRate[si, R] = ARSelect$accept.rate
    
    #ThetaARSelect = huge(Y, lambda=mean(rhos), method="glasso")
    #ThetaARMean = as.matrix(ThetaARSelect$path[[1]])
    
    # Choose the value which is closest to the rho mean:
    
    d = abs(mean(rhos) - L$lambda)
    
    optARPSrhoIndx = which.min(d)[length(which.min(d))] # This is sup{i : rho[i] <= mean(rhos)}
    
    ThetaARPS = as.matrix(L$path[[optARPSrhoIndx]])
    
    ##########################################################
    
    # What is the best Glasso is capable of, condition to the solution path at hand?
    
    AllTheBest = matrix(0, nrho, 5)
    
    for(i in 1:nrho){
      
      AllTheBest[i, ] = unlist(Diagnostic(as.matrix(L$path[[i]]), as.matrix(HugeData$theta)))
      
    }
    
    BestSp[si, R] = max(AllTheBest[ ,1], na.rm = T) # Choose the graphical model that produces the best estimate of specificity
    BestSen[si, R] = max(AllTheBest[ ,2], na.rm = T) # Choose the graphical model that produces the best estimate of sensitivity
    BestFall[si, R] = min(AllTheBest[ ,3], na.rm = T) # Choose the graphical model that produces the best estimate of fall-out
    BestPre[si, R] = max(AllTheBest[ ,4], na.rm = T) # Choose the graphical model that produces the best estimate of precision
    BestMCC[si, R] = max(AllTheBest[ ,5], na.rm = T) # Choose the graphical model that produces the best estimate of MCC
    
    ##########################################################
    
    ARPSResults[si, ,R] = unlist(Diagnostic(ThetaARPS, as.matrix(HugeData$theta)))
    
    cat("\r",si)
    
  }
  
}

#####################################################

ARPSResults[is.na(ARPSResults)] = 0

#####################################################

par(mfrow=c(2,3))

boxplot(ARPSResults[ , 1, ], ylim=c(min(ARPSResults[ , 1, ]), max(apply(BestSp, 2, median))), 
        names=as.character(nrhos), xlab="Nmb of tuning parameters")
title("ARPS Specificity")
points(1:length(nrhos), apply(BestSp, 2, median), col="red", cex=2, pch=16)

boxplot(ARPSResults[ , 2, ], ylim=c(min(ARPSResults[ , 2, ]), max(apply(BestSen, 2, median))), 
        names=as.character(nrhos), xlab="Nmb of tuning parameters")
title("ARPS Sensitivity")
points(1:length(nrhos), apply(BestSen, 2, median), col="red", cex=2, pch=16)

boxplot(ARPSResults[ , 3, ], ylim=c(min(apply(BestFall, 2, median)), max(ARPSResults[ , 3, ])), 
        names=as.character(nrhos), xlab="Nmb of tuning parameters")
title("ARPS Fallout")
points(1:length(nrhos), apply(BestFall, 2, median), col="red", cex=2, pch=16)

boxplot(ARPSResults[ , 4, ], ylim=c(min(ARPSResults[ , 4, ]), max(apply(BestPre, 2, median))), 
        names=as.character(nrhos), xlab="Nmb of tuning parameters")
title("ARPS Precision")
points(1:length(nrhos), apply(BestPre, 2, median), col="red", cex=2, pch=16)

boxplot(ARPSResults[ , 5, ], ylim=c(min(ARPSResults[ , 5, ]), max(apply(BestMCC, 2, median))), 
        names=as.character(nrhos), xlab="Nmb of tuning parameters")
title("ARPS MCC")
points(1:length(nrhos), apply(BestMCC, 2, median), col="red", cex=2, pch=16)

plot(1:length(nrhos), apply(AcceptRate, 2, mean), main="Accept rate", xlab = "Nmb of tuning parameters", xaxt="n", ylab="Accept rate")

axis(side=1, at=1:length(nrhos), labels = FALSE)
text(x=1:length(nrhos), labels = as.character(nrhos), par("usr")[3], pos=1, xpd=T, offset = 0.7)

#####################################################

MergedResultsARPS = data.frame("Nmb of tuning parameters" = rep(nrhos, each=Simrounds), 
                                "Method" = rep("ARPS", dim(ARPSResults)[3]*Simrounds),
                                "Sp" = rep(0, dim(ARPSResults)[3]*Simrounds),
                                "Sen" = rep(0, dim(ARPSResults)[3]*Simrounds), "Fall" = rep(0, dim(ARPSResults)[3]*Simrounds),
                                "Pre" = rep(0, dim(ARPSResults)[3]*Simrounds), "MCC" = rep(0, dim(ARPSResults)[3]*Simrounds))

for(k in 1:dim(ARPSResults)[3]){
  
  MergedResultsARPS[1:Simrounds + (k-1)*Simrounds, -c(1, 2)] = ARPSResults[ , ,k]
  
}

#################

MergedResultsBest = data.frame("Nmb of tuning parameters" = rep(nrhos, each=Simrounds), 
                               "Method" = rep("Oracle", dim(ARPSResults)[3]*Simrounds),
                               "Sp" = as.vector(BestSp),
                                "Sen" = as.vector(BestSen), "Fall" = as.vector(BestFall),
                                "Pre" = as.vector(BestPre), "MCC" = as.vector(BestMCC))



MergedResults = rbind(MergedResultsARPS, MergedResultsBest)



write.table(MergedResults, paste("Results/ARPSMoreTuningParameters_", Model, "_n=", n, "p=", p, "_Class.res.txt", 
                                      sep=""), quote = F)
