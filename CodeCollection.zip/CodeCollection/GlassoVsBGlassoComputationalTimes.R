
# 22.11.2019

# Compare the running times of Glasso and BGlasso

library(MASS)
library(huge)
library(BayesianGLasso)

##########################################################

# Graphical model simulation:

Model = "random"

##########################################################

Dimension = c(100, 200, 300, 400, 500)

Simrounds = 10

nrho = 50

GlassoTime = matrix(0, nrow=Simrounds, ncol = 3)

colnames(GlassoTime) = c("user", "sytem", "elapsed")

BGlassoTime = GlassoTime

GlassoResults = matrix(0, nrow = length(Dimension), ncol=3)

colnames(GlassoResults) = c("user", "sytem", "elapsed")

BGlassoResults = GlassoResults

n = 60 # The sample size does not change although dimension changes

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 84144

set.seed(seed)

##########################################################

for(k in 1:length(Dimension)){
  
  p = Dimension[k]
  
  HugeData = huge.generator(n=10, d=p, graph=Model) # Just the covariance matrix corresponding to the graphical model of
  # interest is needed. Data replications are simulated later.
  
  Sigma = HugeData$sigma
  
  for(si in 1:Simrounds){
    
    Y = mvrnorm(n, rep(0,p), Sigma)
    
    # The whole time of the Glasso process:
    
    GlassoTime[si, ] = system.time(L <<- huge(Y, nlambda=nrho, method="glasso"))[-c(4,5)]
    
    ##########################################################
    
    # Bayes Glasso
    
    # Minimun MCMC length
    
    burnIn = 100
    MCMClength = 100
    
    BGlassoTime[si, ] = system.time(blockGLasso(Y, iterations = MCMClength, burnIn = burnIn))[-c(4,5)]
    
    ##########################################################
    
  }
  
  GlassoResults[k, ] = apply(GlassoTime, 2, mean)
  
  BGlassoResults[k, ] = apply(BGlassoTime, 2, mean)
  
}

#####################################################

MergedGlassoResults = data.frame("Method" = rep("Glasso", 3*length(Dimension)), "Dim" = rep(Dimension, each=3), 
                                 "TimeClass" = rep(colnames(GlassoTime), length(Dimension)), 
                                 "Time" = as.vector(t(GlassoResults)))

MergedBGlassoResults = data.frame("Method" = rep("BGlasso", 3*length(Dimension)), "Dim" = rep(Dimension, each=3), 
                                  "TimeClass" = rep(colnames(BGlassoTime), length(Dimension)), 
                                  "Time" = as.vector(t(BGlassoResults)))


MergedResults = rbind(MergedGlassoResults, MergedBGlassoResults)

write.table(MergedResults, paste("Results/", "GlassovsBGlassoComputationalTimes.txt", sep=""), quote = F, row.names = F)

save.image("GlassovsBGlassoComputationalTimes.RData")
