
# 11.05.2020

# See Wang (2012) page 875 where the conditional posterior of lambda is introduced

library(huge)
library(ggplot2)
library(gtable)
library(grid)
library(gridExtra)
library(HDInterval)

source("RFunctions/ARPS_v2.R")

# A help function to find zero and non-zero entries of the precision matrix for solution paths:

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 20121

set.seed(seed)

##########################################################

# Determine nmb of variables, sample size and the graphical model:

p = 500

#n = c(10, floor(p/2), 10*p)

n = c(200, 8*p, 20*p)

Model = "random"

##########################################################

FiguresPost = list()
FiguresPrior = list()

##########################################################

nrho = 100 # The nmb of tuning parameters

AcceptRate = rep(0, length(n)) # Save the accept-rate

##########################################################

for(i in 1:length(n)){
  
  # Simulate data:
  
  HugeData = huge.generator(n=n[i], d=p, graph=Model)
  
  L = huge(HugeData$data, nlambda=nrho, method="glasso")
  
  #S = cor(HugeData$data)
  
  #lambda.min.ratio = 0.1
  #lambdamax = max(max(S - diag(p)), -min(S - diag(p)))
  #lambdamin = lambda.min.ratio * lambdamax
  #lambda = seq(lambdamax, lambdamin, length = nrho)
  
  #L = huge(HugeData$data, lambda=lambda, method="glasso")
  
  ##########################################################
  
  # Accept-reject algorithm:
  
  MHSelect = ARPS_v2(L, n=n[i], method = "M-H", nSteps = 5*10^4, MH.sampling = "unif")
  
  AcceptRate[i] = MHSelect$accept.rate
  
  rhos = MHSelect$rhos
  
  Randomrhos = sample(L$lambda, length(rhos), replace = T)
  
  
  ##########################################################
  
  # Plot histograms to illustrate the probability of the tuning parameter values sampled with ARPS:
  
  TuningParamPosterior = table(round(rhos, 3))
  
  TuningParamPosterior = data.frame(rho = as.numeric(names(TuningParamPosterior)), 
                                    Prob = as.vector(TuningParamPosterior)/length(rhos))
  
  TuningParamPrior = data.frame(rho = TuningParamPosterior$rho, Prob=1/nrow(TuningParamPosterior))
  
  rhoHDI = hdi(rhos)
  
  Fig = ggplot(TuningParamPosterior, aes(x = rho, y=Prob)) + 
    geom_col(fill="blue", position="stack") +
    scale_x_continuous(trans="log",
                       labels = scales::number_format(accuracy = 0.01)) + 
    # x-axis on natural log-scale
    #xlab("Tuning parameter value") +
    #ylab("Probability") +
    theme(axis.title.x = element_blank(), axis.title.y = element_blank(), 
          axis.text.x = element_text(size=7), axis.text.y = element_text(size=7)) +
    #xlim(0, 1) + # Must be removed when log-scale is used
    ylim(0, max(c(max(TuningParamPosterior$Prob), max(TuningParamPrior$Prob)))) +
    annotate("rect", xmin = as.numeric(rhoHDI[1]), xmax = as.numeric(rhoHDI[2]),
             ymin = 0, 
             ymax = max(c(max(TuningParamPosterior$Prob), max(TuningParamPrior$Prob))), 
             alpha = .5)
  
  Fig2 = ggplot(TuningParamPrior, aes(x = rho, y=Prob)) + 
    geom_col(fill="blue", position="stack") +
    scale_x_continuous(trans="log",
                       labels = scales::number_format(accuracy = 0.01)) + 
    # x-axis on natural log-scale
    #xlab("Tuning parameter value") +
    #ylab("Probability") +
    theme(axis.title.x = element_blank(), axis.title.y = element_blank(), 
          axis.text.x = element_text(size=7), axis.text.y = element_text(size=7)) +
    #xlim(0, 1) +
    ylim(0, max(c(max(TuningParamPosterior$Prob), max(TuningParamPrior$Prob))))
  
  FiguresPost[[i]] = Fig
  
  FiguresPrior[[i]] = Fig2
   
}

FiguresPost[[1]] = FiguresPost[[1]] + ggtitle("Posterior distribution") + theme(plot.title = element_text(hjust = 0.5))
FiguresPrior[[1]] = FiguresPrior[[1]] + ggtitle("Prior distribution") + theme(plot.title = element_text(hjust = 0.5))

FiguresPost[[1]] = FiguresPost[[1]] + labs(tag = "(A1)") + theme(plot.tag = element_text(size = 8))

FiguresPrior[[1]] = FiguresPrior[[1]] + labs(tag = "(A2)") + theme(plot.tag = element_text(size = 8))

FiguresPost[[2]] = FiguresPost[[2]] + labs(tag = "(B1)") + theme(plot.tag = element_text(size = 8))

FiguresPrior[[2]] = FiguresPrior[[2]] + labs(tag = "(B2)") + theme(plot.tag = element_text(size = 8))

FiguresPost[[3]] = FiguresPost[[3]] + labs(tag = "(C1)") + theme(plot.tag = element_text(size = 8))

FiguresPrior[[3]] = FiguresPrior[[3]] + labs(tag = "(C2)") + theme(plot.tag = element_text(size = 8))


grid.arrange(arrangeGrob(FiguresPost[[1]] + theme(legend.position="none"),
                         FiguresPrior[[1]] + theme(legend.position="none"),
                         FiguresPost[[2]] + theme(legend.position="none"),
                         FiguresPrior[[2]] + theme(legend.position="none"),
                         FiguresPost[[3]] + theme(legend.position="none"),
                         FiguresPrior[[3]] + theme(legend.position="none"),
                         ncol = 2,
                         left = textGrob("Probability", rot = 90, vjust = 0.5, gp=gpar(fontface="bold")),
                         bottom = textGrob("Tuning parameter value", vjust=-0.3, gp=gpar(fontface="bold"))),nrow=1)

AcceptRate

scale= 0.9

cairo_ps("Figure2.eps", width = 7*scale, height = 3.4*scale, onefile = T, fallback_resolution = 600)

grid.arrange(arrangeGrob(FiguresPost[[1]] + theme(legend.position="none"),
                         FiguresPrior[[1]] + theme(legend.position="none"),
                         FiguresPost[[2]] + theme(legend.position="none"),
                         FiguresPrior[[2]] + theme(legend.position="none"),
                         FiguresPost[[3]] + theme(legend.position="none"),
                         FiguresPrior[[3]] + theme(legend.position="none"),
                         ncol = 2,
                         left = textGrob("Density", rot = 90, vjust = 0.5, gp=gpar(fontface="bold")),
                         bottom = textGrob("Tuning parameter value", vjust=-0.3, gp=gpar(fontface="bold"))),nrow=1)

dev.off()
