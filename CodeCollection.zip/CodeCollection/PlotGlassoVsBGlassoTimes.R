
# 25.11.2019

# Compare computational times by simple linear plots.

library(ggplot2)

Times = read.table("Results/GlassovsBGlassoComputationalTimes.txt", header = T)

# Report the user time:

Times = Times[Times$TimeClass == "user", ]

Times = Times[, -3]

Times$Time = Times$Time/60 # Time in minutes

cols = c("Glasso" = "black", "BGlasso" = "blue")

p = unique(Times$Dim)

Fig = ggplot(data = Times, aes(x=Dim, y=Time, group=Method)) +
  geom_line(aes(linetype=Method, colour = Method), size=1)+
  geom_point(aes(colour = Method), size=3) +
  scale_linetype_manual(values=c("dotted", "solid")) +
  theme(legend.position="right") + 
  scale_size_manual(values=c(1, 1.5)) +
  ylab("Time (Min)") +
  scale_x_continuous("p", labels = as.character(p), breaks = p)

Fig + scale_colour_manual(values=cols)

Figure1 = Fig + scale_colour_manual(values=cols)

# No legend:

Figure1 = Fig + theme(legend.position = "bottom") + scale_colour_manual(values=cols)

Figure1

postscript("Figure1.eps", width = 2.8, height = 2.4, horizontal = F)

Figure1

dev.off()

