
# 08.05.2020

library(ggplot2)
library(reshape)
library(grid)
library(gridExtra)

source("RFunctions/grid_arrange_shared_legend.R")

# Read results in (denser grid for the tuning parameter)

Results = read.table("Results/ARAndMHMoreTuningParameters_scale-free_n=125p=250_Class.res.txt",
                          header=T, stringsAsFactors = F)

str(Results)

Results$Nmb.of.tuning.parameters = as.character(Results$Nmb.of.tuning.parameters)

ResultsPre = Results[ , c("Method", "Nmb.of.tuning.parameters", "Pre")]

ResultsSen = Results[ , c("Method", "Nmb.of.tuning.parameters", "Sen")]

ResultsMCC = Results[ , c("Method", "Nmb.of.tuning.parameters", "MCC")]

Figure8Pre = ggplot(ResultsPre) +
  geom_boxplot(aes(x=Nmb.of.tuning.parameters, y=Pre, fill=Method)) +
  scale_fill_manual(values=c("#C0C0C0", "#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(x = "") + 
  labs(y="Pre\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold")) + 
  scale_x_discrete(limits=unique(Results$Nmb.of.tuning.parameters))

Figure8Sen = ggplot(ResultsSen) +
  geom_boxplot(aes(x=Nmb.of.tuning.parameters, y=Sen, fill=Method)) +
  scale_fill_manual(values=c("#C0C0C0", "#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(x = expression(paste("Nmb of ", rho))) + 
  labs(y="Sen\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold")) +
  scale_x_discrete(limits=unique(Results$Nmb.of.tuning.parameters))

Figure8MCC = ggplot(ResultsMCC) +
  geom_boxplot(aes(x=Nmb.of.tuning.parameters, y=MCC, fill=Method)) +
  scale_fill_manual(values=c("#C0C0C0", "#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(x = "") + 
  labs(y="MCC\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold")) +
  scale_x_discrete(limits=unique(Results$Nmb.of.tuning.parameters))

grid.arrange(Figure8Pre, Figure8Sen, Figure8MCC, ncol=3,
             top = textGrob(" ", gp=gpar(fontsize=20)))

grid_arrange_shared_legend(Figure8Pre, Figure8Sen, Figure8MCC, ncol=3,
                           top = textGrob(" ", gp=gpar(fontsize=20)))

# Opening a (postscript) file does not work with grid_arrange_shared_legend. Export plot manually using
# the following width and height of the graphics region:

# Figure9

scale = 0.8

72*12*scale # width
72*7*scale # height
