
# 01.11.2019

# Compare computational times by simple linear plots.

library(ggplot2)

Times = read.table("Results/ComputationalTimeCompare.txt", header = T)

# Add the time needed to compute the Glasso solution path to ARPS, RIC and StARS times to give better comparison:

Times[Times$Method == "ARPS", 4] = Times[Times$Method == "ARPS", 4] + Times[Times$Method == "Glasso", 4]

Times[Times$Method == "RIC", 4] = Times[Times$Method == "RIC", 4] + Times[Times$Method == "Glasso", 4]

Times[Times$Method == "StARS", 4] = Times[Times$Method == "StARS", 4] + Times[Times$Method == "Glasso", 4]

# Report the user time:

Times = Times[Times$TimeClass == "user", ]

Times = Times[, -3]

Times$Time = Times$Time/60 # Time in minutes

Times = Times[Times$Method != "Glasso", ]

cols = c("ARPS" = "black", "BGlasso" = "blue", "RIC" = "purple", "StARS" = "red")

p = unique(Times$Dim)

Fig = ggplot(data = Times, aes(x=Dim, y=Time, group=Method)) +
  geom_line(aes(linetype=Method, colour = Method), size=1)+
  geom_point(aes(colour = Method), size=3) +
  scale_linetype_manual(values=c("solid", "dotted", "dotdash", "dashed")) +
  theme(legend.position="right") + 
  scale_size_manual(values=c(1, 1.5)) +
  ylab("Time (Min)") +
  scale_x_continuous("p", labels = as.character(p), breaks = p)

Fig + scale_colour_manual(values=cols)

Figure0 = Fig + scale_colour_manual(values=cols)

# No legend:

Figure0 = Fig + theme(legend.position = "none") + scale_colour_manual(values=cols)

Figure0

postscript("Figure0.eps", width = 3.19, height = 2.48, horizontal = F)

Figure0

dev.off()

##############################

Times[Times$Method == "RIC", 3]/Times[Times$Method == "ARPS", 3]

Times = Times[Times$Method != "StARS", ]
Times = Times[Times$Method != "BGlasso", ]

cols = c("ARPS" = "black", "RIC" = "purple")


Fig = ggplot(data = Times, aes(x=Dim, y=Time, group=Method)) +
  geom_line(aes(linetype=Method, colour = Method), size=1)+
  geom_point(aes(colour = Method), size=3) +
  scale_linetype_manual(values=c("solid", "dotdash")) +
  theme(legend.position="right") + 
  scale_size_manual(values=c(1, 1.5)) +
  ylab("Time (Min)") +
  scale_x_continuous("p", labels = as.character(p), breaks = p)

Fig + scale_colour_manual(values=cols)
