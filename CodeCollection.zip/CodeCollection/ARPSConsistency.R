
# 19.12.2019

# Use the following version of huge

cat("library(huge)",
    sep="\n",
    file="checkpoint_packages_code.R")


library(checkpoint)

checkpoint("2019-11-24")

# How consistent are the results when tuning parameter is selected using Accept-Reject-type algorithm
# in high-dimensions:

library(MASS)
library(huge)

source("RFunctions/SpSeFallPreMCC.txt")
source("RFunctions/ARPS.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 22670

set.seed(seed)

##########################################################

# The graphical model

Model = "hub"

Dimension = c(100, 200, 300, 400, 500, 600)

##########################################################

Simrounds = 10

BestSp   = matrix(0, Simrounds, length(Dimension))
BestSen  = matrix(0, Simrounds, length(Dimension)) 
BestFall = matrix(0, Simrounds, length(Dimension))
BestPre  = matrix(0, Simrounds, length(Dimension))
BestMCC  = matrix(0, Simrounds, length(Dimension))

AcceptRate = matrix(0, Simrounds, length(Dimension))

ARPSResults = array(0, c(Simrounds, 5, length(Dimension)))

colnames(ARPSResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

RICResults = ARPSResults

##########################################################

nrho = 100

for(P in 1:length(Dimension)){
  
  # Graphical model simulation:
  
  p = Dimension[P]
  
  HugeData = huge.generator(n=10, d=p, graph=Model) # Just the precision matrix corresponding to the graphical model of
  # interest is needed. Data is simulated later.
  
  Sigma = HugeData$sigma
  
  n = floor(p/2) # This is more or less an arbitrary proportion.
  
  for(si in 1:Simrounds){
    
    Y = mvrnorm(n, rep(0,p), Sigma)
    
    L = huge(Y, nlambda=nrho, method="glasso")
    
    ##########################################################
    
    # Accept-reject algorithm:
    
    ARSelect = ARPS(L, n=nrow(Y))
    
    rhos = ARSelect$rhos
    
    AcceptRate[si, P] = ARSelect$accept.rate
    
    #ThetaARSelect = huge(Y, lambda=mean(rhos), method="glasso")
    #ThetaARMean = as.matrix(ThetaARSelect$path[[1]])
    
    # Choose the value which is closest to the rho mean:
    
    d = abs(mean(rhos) - L$lambda)
    
    optARPSrhoIndx = which.min(d)[length(which.min(d))]
    
    ThetaARPS = as.matrix(L$path[[optARPSrhoIndx]])
    
    ##########################################################
    
    # RIC
    
    HugeSelectRIC = huge.select(L, criterion = "ric")
    
    ##########################################################
    
    # What is the best Glasso is capable of, condition to the solution path at hand?
    
    AllTheBest = matrix(0, nrho, 5)
    
    for(i in 1:nrho){
      
      AllTheBest[i, ] = unlist(Diagnostic(as.matrix(L$path[[i]]), as.matrix(HugeData$theta)))
      
    }
    
    BestSp[si, P] = max(AllTheBest[ ,1], na.rm = T) # Choose the graphical model that produces the best estimate of specificity
    BestSen[si, P] = max(AllTheBest[ ,2], na.rm = T) # Choose the graphical model that produces the best estimate of sensitivity
    BestFall[si, P] = min(AllTheBest[ ,3], na.rm = T) # Choose the graphical model that produces the best estimate of fall-out
    BestPre[si, P] = max(AllTheBest[ ,4], na.rm = T) # Choose the graphical model that produces the best estimate of precision
    BestMCC[si, P] = max(AllTheBest[ ,5], na.rm = T) # Choose the graphical model that produces the best estimate of MCC
    
    ##########################################################
    
    ARPSResults[si, ,P] = unlist(Diagnostic(ThetaARPS, as.matrix(HugeData$theta)))
    
    RICResults[si, ,P] = unlist(Diagnostic(as.matrix(HugeSelectRIC$refit), as.matrix(HugeData$theta)))
    
    cat("\r",si)
    
  }
  
}

#####################################################

ARPSResults[is.na(ARPSResults)] = 0

#####################################################

par(mfrow=c(2,3))

boxplot(ARPSResults[ , 1, ], ylim=c(min(ARPSResults[ , 1, ]), max(apply(BestSp, 2, median))), 
        names=as.character(Dimension), xlab="p")
title("ARPS Specificity")
points(1:length(Dimension), apply(BestSp, 2, median), col="red", cex=2, pch=16)

boxplot(ARPSResults[ , 2, ], ylim=c(min(ARPSResults[ , 2, ]), max(apply(BestSen, 2, median))), 
        names=as.character(Dimension), xlab="p")
title("ARPS Sensitivity")
points(1:length(Dimension), apply(BestSen, 2, median), col="red", cex=2, pch=16)

boxplot(ARPSResults[ , 3, ], ylim=c(min(apply(BestFall, 2, median)), max(ARPSResults[ , 3, ])), 
        names=as.character(Dimension), xlab="p")
title("ARPS Fallout")
points(1:length(Dimension), apply(BestFall, 2, median), col="red", cex=2, pch=16)

boxplot(ARPSResults[ , 4, ], ylim=c(min(ARPSResults[ , 4, ]), max(apply(BestPre, 2, median))), 
        names=as.character(Dimension), xlab="p")
title("ARPS Precision")
points(1:length(Dimension), apply(BestPre, 2, median), col="red", cex=2, pch=16)

boxplot(ARPSResults[ , 5, ], ylim=c(min(ARPSResults[ , 5, ]), max(apply(BestMCC, 2, median))), 
        names=as.character(Dimension), xlab="p")
title("ARPS MCC")
points(1:length(Dimension), apply(BestMCC, 2, median), col="red", cex=2, pch=16)

plot(1:length(Dimension), apply(AcceptRate, 2, mean), main="Accept rate", xlab = "p", xaxt="n", ylab="Accept rate")

axis(side=1, at=1:length(Dimension), labels = FALSE)
text(x=1:length(Dimension), labels = as.character(Dimension), par("usr")[3], pos=1, xpd=T, offset = 0.7)

#####################################################

MergedResultsARPS = data.frame("p" = rep(Dimension, each=Simrounds), "Sp" = rep(0, dim(ARPSResults)[3]*Simrounds),
                           "Sen" = rep(0, dim(ARPSResults)[3]*Simrounds), "Fall" = rep(0, dim(ARPSResults)[3]*Simrounds),
                           "Pre" = rep(0, dim(ARPSResults)[3]*Simrounds), "MCC" = rep(0, dim(ARPSResults)[3]*Simrounds))

for(k in 1:dim(ARPSResults)[3]){
  
  MergedResultsARPS[1:Simrounds + (k-1)*Simrounds, -1] = ARPSResults[ , ,k]
  
}

write.table(MergedResultsARPS, paste("Results/ARPSConsistency_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), quote = F)

#####################################################

MergedResultsRIC = data.frame("p" = rep(Dimension, each=Simrounds), "Sp" = rep(0, dim(RICResults)[3]*Simrounds),
                           "Sen" = rep(0, dim(RICResults)[3]*Simrounds), "Fall" = rep(0, dim(RICResults)[3]*Simrounds),
                           "Pre" = rep(0, dim(RICResults)[3]*Simrounds), "MCC" = rep(0, dim(RICResults)[3]*Simrounds))

for(k in 1:dim(RICResults)[3]){
  
  MergedResultsRIC[1:Simrounds + (k-1)*Simrounds, -1] = RICResults[ , ,k]
  
}

write.table(MergedResultsRIC, paste("Results/RICConsistency_", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), quote = F)
