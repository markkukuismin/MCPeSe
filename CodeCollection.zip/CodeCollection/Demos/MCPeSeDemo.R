
# 20.05.2020

# MCPeSe demo with both Accept-Reject and Metropolis-Hastings methods

# See Wang (2012) page 875 where the conditional posterior of lambda is introduced

library(MASS)
library(huge)
library(HDInterval)

source("../RFunctions/mcpese.R")
source("../RFunctions/SpSeFallPreMCC.txt")

# A help function to find zero and non-zero entries of the precision matrix for solution paths:

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 90501

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 200

Model = "hub"

HugeData = huge.generator(n=10, d=p, graph=Model) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

Sigma = HugeData$sigma

Theta = HugeData$omega

n = 210

Y = mvrnorm(n, rep(0,p), Sigma)

nlambda = 100

Y = scale(Y)

L = huge(Y, nlambda=nlambda, method="glasso")

##########################################################

# Accept-reject algorithm:

ARSelectUnifPrior = mcpese(L, n=nrow(Y), method="A-R", M=10^4)

MHSelectUnifPrior = mcpese(L, n=nrow(Y), method="M-H", nSteps=10^4, MH.sampling="unif")

MHSelectGammaPrior = mcpese(L, n=nrow(Y), method="M-H", prior="gamma", 
                           rhoPriora = 0.001, rhoPriorb = 1000, nSteps=10^4, MH.sampling = "unif")

MHSelectDefaultGammaPrior = mcpese(L, n=nrow(Y), method="M-H", prior="gamma", 
                                    nSteps=10^4, MH.sampling = "unif")

plot(MHSelectUnifPrior$rhos, type="l")

plot(MHSelectDefaultGammaPrior$rhos, type="l")

par(mfrow=c(2, 2))

barplot(table(ARSelectUnifPrior$rhos), main="A-R, unif prior", xaxt = "n")

barplot(table(MHSelectDefaultGammaPrior$rhos), main="M-H, default gamma prior", xaxt = "n")

barplot(table(MHSelectUnifPrior$rhos), main="M-H, unif prior", xaxt = "n")

barplot(table(MHSelectGammaPrior$rhos), main="M-H, gamma, Jeffreys", xaxt = "n")

##########################################################

d = hdi(ARSelectUnifPrior$rhos)

plot(d, rep(0, 2), ylim=c(0, 1), xlim=c(min(L$lambda), max(L$lambda)))

axis(1, at = ARSelectUnifPrior$opt.rho, col="red", labels = NA, tck = 0.5, lty = 2)

##

d = hdi(MHSelectUnifPrior$rhos)

plot(d, rep(0, 2), ylim=c(0, 1), xlim=c(min(L$lambda), max(L$lambda)))

axis(1, at = MHSelectUnifPrior$opt.rho, col="red", labels = NA, tck = 0.5, lty = 2)

##

d = hdi(MHSelectGammaPrior$rhos)

plot(d, rep(0, 2), ylim=c(0, 1), xlim=c(min(L$lambda), max(L$lambda)))

axis(1, at = MHSelectGammaPrior$opt.rho, col="red", labels = NA, tck = 0.5, lty = 2)

##

d = hdi(MHSelectDefaultGammaPrior$rhos)

plot(d, rep(0, 2), ylim=c(0, 1), xlim=c(min(L$lambda), max(L$lambda)))

axis(1, at = MHSelectDefaultGammaPrior$opt.rho, col="red", labels = NA, tck = 0.5, lty = 2)

##########################################################

huge.plot(HugeData$theta)

title("Ground truth")


huge.plot(L$path[[ARSelectUnifPrior$opt.index]])

title("A-R uniform prior")


huge.plot(L$path[[MHSelectUnifPrior$opt.index]])

title("M-H uniform prior")


huge.plot(L$path[[MHSelectDefaultGammaPrior$opt.index]])

title("M-H default Gamma prior")


huge.plot(L$path[[MHSelectGammaPrior$opt.index]])

title("M-H Jeffreys Gamma prior")
