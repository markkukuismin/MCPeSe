
# 20.05.2020

# Choose tuning parameter using Monte Carlo methods:

cat("library(huge)",
    sep="\n",
    file="checkpoint_packages_code.R")

# I have had problems with huge version newer than v 1.2.7 while running StARS...

library(checkpoint)

checkpoint("2018-08-01")

library(MASS)
library(huge)

source("../RFunctions/SpSeFallPreMCC.txt")
source("../RFunctions/mcpese.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 22670

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 500

Model = "random" # random, scale-free, hub, cluster and band

HugeData = huge.generator(n=10, d=p, graph=Model) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

Sigma = HugeData$sigma

n = 200

nrho = 50 # nmb of used tuning parameters

##########################################################

Simrounds = 100

ARrho = rep(0, Simrounds)

MHUnifRWrho = ARrho
MHGammaRWrho = ARrho

MHUnifUWrho = ARrho
MHGammaUWrho = ARrho

BestSp = rep(0, Simrounds)
BestSen = rep(0, Simrounds) 
BestFall = rep(0, Simrounds)
BestPre = rep(0, Simrounds)
BestMCC = rep(0, Simrounds)

AcceptRate = rep(0, Simrounds)

ARResults = matrix(0, Simrounds, 5)
colnames(ARResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

MHUnifUnifWalkResults = ARResults
MHGammaUnifWalkResults = ARResults

MHUnifRandomWalkResults = ARResults
MHGammaRandomWalkResults = ARResults

EBICResults = ARResults
RICResults = ARResults
StARSResults = ARResults
RandomResults = ARResults

BestResults = ARResults # For orcale method

##########################################################

for(si in 1:Simrounds){
  
  Y = mvrnorm(n, rep(0,p), Sigma)
  
  # Compute nrho GGMs with Glasso
  
  L = huge(Y, nlambda=nrho, method="glasso")
  
  ##########################################################
  
  # Accept-reject algorithm:
  
  ARSelect = mcpese(L, n=nrow(Y), M=10^5, method="A-R")
  
  rhosAR = ARSelect$rhos
  
  # Choose the value which is smallest of the tuning parameter values larger than the 
  # mean of tuning parameter values sampled:
  
  optARrhoIndx = ARSelect$opt.index
  
  ThetaAR = as.matrix(L$path[[optARrhoIndx]])
  
  ARrho[si] = ARSelect$opt.rho
  
  ##########################################################
  
  # Metropolis-Hastings algorithm, Unif prior + random walk:
  
  MHSelectUnifRW = mcpese(L, n=nrow(Y), method="M-H", prior="unif", 
                         nSteps = 5*10^4, MH.sampling = "random.walk")
  
  rhosMHUnifRW = MHSelectUnifRW$rhos
  
  # Choose the value which is smallest of the tuning parameter values larger than the 
  # mean of tuning parameter values sampled:
  
  optMHUnifRW_rhoIndx = MHSelectUnifRW$opt.index
  
  ThetaMHUnifRW = as.matrix(L$path[[optMHUnifRW_rhoIndx]])
  
  MHUnifRWrho[si] = MHSelectUnifRW$opt.rho
  
  ##########################################################
  
  # Metropolis-Hastings algorithm, Wang (2012) Gamma prior + random walk:
  
  MHSelectGamma = mcpese(L, n=nrow(Y), method="M-H", prior="gamma", 
                          nSteps = 5*10^4, MH.sampling = "random.walk")
  
  rhosMHGammaRW = MHSelectGamma$rhos
  
  # Choose the value which is smallest of the tuning parameter values larger than the 
  # mean of tuning parameter values sampled:
  
  optMHGammaRW_rhoIndx = MHSelectGamma$opt.index
  
  ThetaMHGammaRW = as.matrix(L$path[[optMHGammaRW_rhoIndx]])
  
  MHGammaRWrho[si] = MHSelectGamma$opt.rho
  
  ##########################################################
  
  # Metropolis-Hastings algorithm, Unif prior + unif walk:
  
  MHSelectUnifUW = mcpese(L, n=nrow(Y), method="M-H", prior="unif", 
                         nSteps = 5*10^4, MH.sampling = "unif")
  
  rhosMHUnifUW = MHSelectUnifUW$rhos
  
  # Choose the value which is smallest of the tuning parameter values larger than the 
  # mean of tuning parameter values sampled:
  
  optMHUnifUW_rhoIndx = MHSelectUnifUW$opt.index
  
  ThetaMHUnifUW = as.matrix(L$path[[optMHUnifUW_rhoIndx]])
  
  MHUnifUWrho[si] = MHSelectUnifUW$opt.rho
  
  ##########################################################
  
  # Metropolis-Hastings algorithm, Wang (2012) Gamma prior + unif walk:
  
  MHSelectGammaUW = mcpese(L, n=nrow(Y), method="M-H", prior="gamma", 
                           nSteps = 5*10^4, MH.sampling = "unif")
  
  rhosMHGammaUW = MHSelectGammaUW$rhos
  
  # Choose the value which is smallest of the tuning parameter values larger than the 
  # mean of tuning parameter values sampled:
  
  optMHGammaUW_rhoIndx = MHSelectGammaUW$opt.index
  
  ThetaMHGammaUW = as.matrix(L$path[[optMHGammaUW_rhoIndx]])
  
  MHGammaUWrho[si] = MHSelectGammaUW$opt.rho
  
  ##########################################################
  
  # What is the best Glasso is capable of (an oracle method), condition to the solution path at hand?
  
  AllTheBest = matrix(0, nrho, 5)
  
  for(i in 1:nrho){
    
    AllTheBest[i, ] = unlist(Diagnostic(as.matrix(L$path[[i]]), as.matrix(HugeData$theta)))
    
  }
  
  BestSp[si] = max(AllTheBest[ ,1], na.rm = T) # Choose the graphical model that produces the best estimate of specificity
  BestSen[si] = max(AllTheBest[ ,2], na.rm = T) # Choose the graphical model that produces the best estimate of sensitivity
  BestFall[si] = min(AllTheBest[ ,3], na.rm = T) # Choose the graphical model that produces the best estimate of fall-out
  BestPre[si] = max(AllTheBest[ ,4], na.rm = T) # Choose the graphical model that produces the best estimate of precision
  BestMCC[si] = max(AllTheBest[ ,5], na.rm = T) # Choose the graphical model that produces the best estimate of MCC
  
  ##########################################################
  
  # eBIC
  
  # Run eBIC with multiple parameter gamma values. Choose the one which maximizes estimate of MCC (oracle model):
  
  gamma = c(0, 0.005, 0.01, 0.05, 0.1, 0.5)
  MCC = rep(0,length(gamma))
  
  for(i in 1:length(gamma)){
    
    HugeSelectEBIC = huge.select(L, ebic.gamma=gamma[i], criterion="ebic")
    
    MCC[i] = Diagnostic(as.matrix(HugeSelectEBIC$refit), as.matrix(HugeData$theta))$MCC
    
  }
  
  MCC[is.na(MCC)] = 0
  
  HugeSelectEBIC = huge.select(L, ebic.gamma=gamma[which.max(MCC)], criterion="ebic")
  
  ##########################################################
  
  # RIC
  
  HugeSelectRIC = huge.select(L, criterion = "ric")
  
  ##########################################################
  
  # StARS
  
  # Run StARS with two parameter values. Choose the one which maximizes estimate of MCC (oracle model):
  
  MCC = rep(0, 2)
  
  HugeSelectStARS = huge.select(L, stars.thresh = 0.05, criterion="stars")
  
  AStARS = as.matrix(L$path[[HugeSelectStARS$opt.index]])
  
  MCC[1] = Diagnostic(AStARS, as.matrix(HugeData$theta))$MCC
  
  StARS.opt.index.01 = max(which.max(HugeSelectStARS$variability >= 0.1)[1] - 1, 1)
  
  MCC[2] = Diagnostic(as.matrix(L$path[[StARS.opt.index.01]]), as.matrix(HugeData$theta))$MCC
  
  MCC[is.na(MCC)] = 0
  
  if(MCC[2] >= MCC[1]) AStARS = as.matrix(L$path[[StARS.opt.index.01]])
  
  ##########################################################
  
  ARResults[si, ] = unlist(Diagnostic(ThetaAR, as.matrix(HugeData$theta)))
  
  MHUnifRandomWalkResults[si, ] = unlist(Diagnostic(ThetaMHUnifRW, as.matrix(HugeData$theta)))
  
  MHGammaRandomWalkResults[si, ] = unlist(Diagnostic(ThetaMHGammaRW, as.matrix(HugeData$theta)))
  
  MHUnifUnifWalkResults[si, ] = unlist(Diagnostic(ThetaMHUnifUW, as.matrix(HugeData$theta)))
  
  MHGammaUnifWalkResults[si, ] = unlist(Diagnostic(ThetaMHGammaUW, as.matrix(HugeData$theta)))
  
  EBICResults[si, ] = unlist(Diagnostic(as.matrix(HugeSelectEBIC$refit), as.matrix(HugeData$theta)))
  
  RICResults[si, ] = unlist(Diagnostic(as.matrix(HugeSelectRIC$refit), as.matrix(HugeData$theta)))
  
  StARSResults[si, ] = unlist(Diagnostic(AStARS, as.matrix(HugeData$theta)))
  
  RandomResults[si, ] = unlist(Diagnostic(as.matrix(L$path[[sample(1:nrho,1)]]),
                                          as.matrix(HugeData$theta))) # a random graphical model from the solution path
  
  AcceptRate[si] = ARSelect$accept.rate
  
  cat("\r",si)
  
}

BestResults[ , 1] = BestSp
BestResults[ , 2] = BestSen
BestResults[ , 3] = BestFall
BestResults[ , 4] = BestPre
BestResults[ , 5] = BestMCC

# Plot networks

huge.plot(HugeData$theta) # Truth
title("Ground truth")

huge.plot(HugeSelectEBIC$refit)# eBIC
title("eBIC")

huge.plot(HugeSelectRIC$refit)
title("RIC")

huge.plot(AStARS)
title("StARS")

huge.plot(L$path[[optARrhoIndx]])
title("Reject sampling")

huge.plot(L$path[[optMHUnifRW_rhoIndx]])
title("M-H Unif prior, random walk")

huge.plot(L$path[[optMHGammaRW_rhoIndx]])
title("M-H Gamma prior, random walk")

huge.plot(L$path[[optMHUnifUW_rhoIndx]])
title("M-H Unif prior, uniform walk")

huge.plot(L$path[[optMHGammaUW_rhoIndx]])
title("M-H Gamma prior, uniform walk")

#####################################################

ARResults[is.na(ARResults)] = 0
MHUnifRandomWalkResults[is.na(MHUnifRandomWalkResults)] = 0
MHGammaRandomWalkResults[is.na(MHGammaRandomWalkResults)] = 0
MHUnifUnifWalkResults[is.na(MHUnifUnifWalkResults)] = 0
MHGammaUnifWalkResults[is.na(MHGammaUnifWalkResults)] = 0
EBICResults[is.na(EBICResults)] = 0
RICResults[is.na(RICResults)] = 0
StARSResults[is.na(StARSResults)] = 0
RandomResults[is.na(RandomResults)] = 0


#####################################################

par(mfrow=c(3,3))

boxplot(ARResults, ylim=c(0,1))
title("Accept-reject sampling")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(MHUnifRandomWalkResults, ylim=c(0,1))
title("M-H, Unif prior, random walk")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(MHGammaRandomWalkResults, ylim=c(0,1))
title("M-H, Gamma prior, random walk")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(MHUnifUnifWalkResults, ylim=c(0,1))
title("M-H, Unif prior, uniform walk")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(MHGammaUnifWalkResults, ylim=c(0,1))
title("M-H, Gamma prior, uniform walk")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(RICResults, ylim=c(0,1))
title("RIC")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(EBICResults, ylim=c(0,1))
title("eBIC")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(StARSResults, ylim=c(0,1))
title("StARS")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

#####################################################

ARResults = data.frame("Method" = rep("AR", Simrounds), ARResults)

MHUnifRandomWalkResults = data.frame("Method" = rep("MHUnifRW", Simrounds), MHUnifRandomWalkResults)
MHGammaRandomWalkResults = data.frame("Method" = rep("MHGammaRW", Simrounds), MHGammaRandomWalkResults)

MHUnifUnifWalkResults = data.frame("Method" = rep("MHUnifUW", Simrounds), MHUnifUnifWalkResults)
MHGammaUnifWalkResults = data.frame("Method" = rep("MHGammaUW", Simrounds), MHGammaUnifWalkResults)

EBICResults = data.frame("Method" = rep("eBIC", Simrounds), EBICResults)
RICResults = data.frame("Method" = rep("RIC", Simrounds), RICResults)
StARSResults = data.frame("Method" = rep("StARS", Simrounds), StARSResults)
RandomResults = data.frame("Method" = rep("Random", Simrounds), RandomResults)
BestResults = data.frame("Method" = rep("Oracle", Simrounds), BestResults)

MergedResults = rbind(ARResults, 
                      MHUnifRandomWalkResults, MHGammaRandomWalkResults,
                      MHUnifUnifWalkResults, MHGammaUnifWalkResults,
                      EBICResults, RICResults, StARSResults, 
                      RandomResults, BestResults)

write.table(MergedResults, paste("../Results/", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), quote = F)

#####################################################

par(mfrow=c(1,1))

barplot(table(rhosAR)/sum(table(rhosAR)), xaxt = "n", main="A-R sampling")

#

barplot(table(rhosMHUnifRW)/sum(table(rhosMHUnifRW)), xaxt = "n", 
        main = "M-H sampling, Unif prior, random walk")

#

barplot(table(rhosMHGammaRW)/sum(rhosMHGammaRW), xaxt = "n", 
        main = "M-H sampling, Gamma prior, random walk")

#

barplot(table(rhosMHUnifUW)/sum(table(rhosMHUnifUW)), xaxt = "n", 
        main = "M-H sampling, Unif prior, unif walk")

#

barplot(table(rhosMHGammaUW)/sum(table(rhosMHGammaUW)), xaxt = "n", 
        main = "M-H sampling, Gamma prior, unif walk")

