
# 07.01.2020

# Choose tuning parameter using Accept-Reject-type algorithm:

library(MASS)
library(huge)

source("RFunctions/SpSeFallPreMCC.txt")
source("RFunctions/ARPS.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 22670

set.seed(seed)

##########################################################

# Graphical model simulation:

p = 500

Model = "random" # random, scale-free, hub, cluster and band

HugeData = huge.generator(n=10, d=p, graph=Model) # Just the precision matrix corresponding to the graphical model of
# interest is needed. Data is simulated later.

Sigma = HugeData$sigma

n = 200

nrho = 50 # nmb of used tuning parameters

##########################################################

Simrounds = 50

ARPSrho = rep(0, Simrounds)

BestSp = rep(0, Simrounds)
BestSen = rep(0, Simrounds) 
BestFall = rep(0, Simrounds)
BestPre = rep(0, Simrounds)
BestMCC = rep(0, Simrounds)

AcceptRate = rep(0, Simrounds)

ARPSResults = matrix(0, Simrounds, 5)
colnames(ARPSResults) = c("Sp", "Sen", "Fall", "Pre", "MCC")

EBICResults = ARPSResults
RICResults = ARPSResults
StARSResults = ARPSResults
RandomResults = ARPSResults

BestResults = ARPSResults # For orcale method

##########################################################

for(si in 1:Simrounds){
  
  Y = mvrnorm(n, rep(0,p), Sigma)
  
  # Compute nrho GGMs with Glasso
  
  L = huge(Y, nlambda=nrho, method="glasso")
  
  ##########################################################
  
  # Accept-reject algorithm:
  
  ARSelect = ARPS(L, n=nrow(Y))
  
  rhos = ARSelect$rhos
  
  #ThetaARSelect = huge(Y, lambda=mean(rhos), method="glasso")
  #ThetaARMean = as.matrix(ThetaARSelect$path[[1]])
  
  # Choose the value which is closest to the rho mean:
  
  d = abs(mean(rhos) - L$lambda)
  
  optARPSrhoIndx = which.min(d)[length(which.min(d))]
  
  ThetaARPS = as.matrix(L$path[[optARPSrhoIndx]])
  
  ARPSrho[si] = L$lambda[optARPSrhoIndx]
  
  ##########################################################
  
  # What is the best Glasso is capable of (an oracle method), condition to the solution path at hand?
  
  AllTheBest = matrix(0, nrho, 5)
  
  for(i in 1:nrho){
    
    AllTheBest[i, ] = unlist(Diagnostic(as.matrix(L$path[[i]]), as.matrix(HugeData$theta)))
    
  }
  
  BestSp[si] = max(AllTheBest[ ,1], na.rm = T) # Choose the graphical model that produces the best estimate of specificity
  BestSen[si] = max(AllTheBest[ ,2], na.rm = T) # Choose the graphical model that produces the best estimate of sensitivity
  BestFall[si] = min(AllTheBest[ ,3], na.rm = T) # Choose the graphical model that produces the best estimate of fall-out
  BestPre[si] = max(AllTheBest[ ,4], na.rm = T) # Choose the graphical model that produces the best estimate of precision
  BestMCC[si] = max(AllTheBest[ ,5], na.rm = T) # Choose the graphical model that produces the best estimate of MCC
  
  ##########################################################
  
  # eBIC
  
  # Run eBIC with multiple parameter gamma values. Choose the one which maximizes estimate of MCC (oracle model):
  
  gamma = c(0, 0.005, 0.01, 0.05, 0.1, 0.5)
  MCC = rep(0,length(gamma))
  
  for(i in 1:length(gamma)){
    
    HugeSelectEBIC = huge.select(L, ebic.gamma=gamma[i], criterion="ebic")
    
    MCC[i] = Diagnostic(as.matrix(HugeSelectEBIC$refit), as.matrix(HugeData$theta))$MCC
    
  }
  
  MCC[is.na(MCC)] = 0
  
  HugeSelectEBIC = huge.select(L, ebic.gamma=gamma[which.max(MCC)], criterion="ebic")
  
  ##########################################################
  
  # RIC
  
  HugeSelectRIC = huge.select(L, criterion = "ric")
  
  ##########################################################
  
  # StARS
  
  # Run StARS with two parameter values. Choose the one which maximizes estimate of MCC (oracle model):
  
  threshold = c(0.05, 0.1)
  MCC = rep(0,length(threshold))
  
  for(i in 1:length(threshold)){
    
    HugeSelectStARS = huge.select(L, stars.thresh = threshold[i], criterion="stars")
    
    MCC[i] = Diagnostic(as.matrix(HugeSelectStARS$refit), as.matrix(HugeData$theta))$MCC
    
  }
  
  MCC[is.na(MCC)] = 0
  
  HugeSelectStARS = huge.select(L, stars.thresh = threshold[which.max(MCC)], criterion="stars")
  
  ##########################################################
  
  ARPSResults[si, ] = unlist(Diagnostic(ThetaARPS, as.matrix(HugeData$theta)))
  
  EBICResults[si, ] = unlist(Diagnostic(as.matrix(HugeSelectEBIC$refit), as.matrix(HugeData$theta)))
  
  RICResults[si, ] = unlist(Diagnostic(as.matrix(HugeSelectRIC$refit), as.matrix(HugeData$theta)))
  
  StARSResults[si, ] = unlist(Diagnostic(as.matrix(HugeSelectStARS$refit), as.matrix(HugeData$theta)))
  
  RandomResults[si, ] = unlist(Diagnostic(as.matrix(L$path[[sample(1:nrho,1)]]),
                                          as.matrix(HugeData$theta))) # a random graphical model from the solution path
  
  AcceptRate[si] = ARSelect$accept.rate
  
  cat("\r",si)
  
}

BestResults[ , 1] = BestSp
BestResults[ , 2] = BestSen
BestResults[ , 3] = BestFall
BestResults[ , 4] = BestPre
BestResults[ , 5] = BestMCC

# Plot networks

huge.plot(HugeData$theta) # Truth
title("Ground truth")

huge.plot(HugeSelectEBIC$refit)# eBIC
title("eBIC")

huge.plot(HugeSelectRIC$refit)
title("RIC")

huge.plot(HugeSelectStARS$refit)
title("StARS")

huge.plot(L$path[[optARPSrhoIndx]])
title("Reject sampling")

#####################################################

ARPSResults[is.na(ARPSResults)] = 0
EBICResults[is.na(EBICResults)] = 0
RICResults[is.na(RICResults)] = 0
StARSResults[is.na(StARSResults)] = 0
RandomResults[is.na(RandomResults)] = 0

#####################################################

par(mfrow=c(2,3))

boxplot(ARPSResults, ylim=c(0,1))
title("Accept-reject sampling")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(RICResults, ylim=c(0,1))
title("RIC")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(EBICResults, ylim=c(0,1))
title("eBIC")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(StARSResults, ylim=c(0,1))
title("StARS")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

boxplot(RandomResults, ylim=c(0,1))
title("Random")
points(1:5, c(median(BestSp), median(BestSen), median(BestFall), median(BestPre), median(BestMCC)), col="red", cex=2, pch=16)

#####################################################

ARPSResults = data.frame("Method" = rep("ARPS", Simrounds), ARPSResults)
EBICResults = data.frame("Method" = rep("eBIC", Simrounds), EBICResults)
RICResults = data.frame("Method" = rep("RIC", Simrounds), RICResults)
StARSResults = data.frame("Method" = rep("StARS", Simrounds), StARSResults)
RandomResults = data.frame("Method" = rep("Random", Simrounds), RandomResults)
BestResults = data.frame("Method" = rep("Oracle", Simrounds), BestResults)

MergedResults = rbind(ARPSResults, EBICResults, RICResults, StARSResults, RandomResults, BestResults)

write.table(MergedResults, paste("Results/", Model, "_n=", n, "p=", p, "_Class.res.txt", sep=""), quote = F)

#####################################################

par(mfrow=c(1,1))
hist(rhos, probability = T, xlim=c(0,1))
lines(density(rhos), col="red", lty=2)
lines(density(sample(L$lambda, 1000, replace = T)), col="blue", lty=2)

legend("topright", bty="n", legend=c("Reject sampling","Resampled rho density"), lty=2, col=c("red","blue"))
