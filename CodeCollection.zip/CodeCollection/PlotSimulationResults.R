
# 4.11.2019

library(ggplot2)
library(reshape)
library(grid)
library(gridExtra)

# Read data in

ResultsBand = read.table("Results/band_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)
ResultsScaleFree = read.table("Results/scale-free_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)
ResultsCluster = read.table("Results/cluster_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)
ResultsRandom = read.table("Results/random_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)
ResultsHub = read.table("Results/hub_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)

str(ResultsBand)

#############################

# Plot boxplots

# Band model

OraclePre = ResultsBand[ResultsBand$Method == "Oracle", "Pre"]
OracleSen = ResultsBand[ResultsBand$Method == "Oracle", "Sen"]
OracleMCC = ResultsBand[ResultsBand$Method == "Oracle", "MCC"]

ResultsBand = ResultsBand[!ResultsBand$Method == "Oracle", ]

Figure3Pre = ggplot(ResultsBand) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure3Sen = ggplot(ResultsBand) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure3MCC = ggplot(ResultsBand) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5, size=16),
        axis.title=element_text(size=14,face="bold"))


grid.arrange(Figure3Pre, Figure3Sen, Figure3MCC, ncol=3,
             top = textGrob("Band model", gp=gpar(fontsize=20)))


scale = 0.8

postscript("Figure3.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure3Pre, Figure3Sen, Figure3MCC, ncol=3,
             top = textGrob("Band model", gp=gpar(fontsize=20)))

dev.off()

#############################

# Scale-free model

OraclePre = ResultsScaleFree[ResultsScaleFree$Method == "Oracle", "Pre"]
OracleSen = ResultsScaleFree[ResultsScaleFree$Method == "Oracle", "Sen"]
OracleMCC = ResultsScaleFree[ResultsScaleFree$Method == "Oracle", "MCC"]

ResultsScaleFree = ResultsScaleFree[!ResultsScaleFree$Method == "Oracle", ]

Figure4Pre = ggplot(ResultsScaleFree) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure4Sen = ggplot(ResultsScaleFree) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure4MCC = ggplot(ResultsScaleFree) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid.arrange(Figure4Pre, Figure4Sen, Figure4MCC, ncol=3,
             top = textGrob("Scale-free model", gp=gpar(fontsize=20)))

scale= 0.8

postscript("Figure4.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure4Pre, Figure4Sen, Figure4MCC, ncol=3,
             top = textGrob("Scale-free model", gp=gpar(fontsize=20)))

dev.off()

#############################

OraclePre = ResultsCluster[ResultsCluster$Method == "Oracle", "Pre"]
OracleSen = ResultsCluster[ResultsCluster$Method == "Oracle", "Sen"]
OracleMCC = ResultsCluster[ResultsCluster$Method == "Oracle", "MCC"]

ResultsCluster = ResultsCluster[!ResultsCluster$Method == "Oracle", ]

Figure5Pre = ggplot(ResultsCluster) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure5Sen = ggplot(ResultsCluster) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure5MCC = ggplot(ResultsCluster) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid.arrange(Figure5Pre, Figure5Sen, Figure5MCC, ncol=3,
             top = textGrob("Cluster model", gp=gpar(fontsize=20)))

scale= 0.8

postscript("Figure5.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure5Pre, Figure5Sen, Figure5MCC, ncol=3,
             top = textGrob("Cluster model", gp=gpar(fontsize=20)))

dev.off()

#############################

OraclePre = ResultsRandom[ResultsRandom$Method == "Oracle", "Pre"]
OracleSen = ResultsRandom[ResultsRandom$Method == "Oracle", "Sen"]
OracleMCC = ResultsRandom[ResultsRandom$Method == "Oracle", "MCC"]

ResultsRandom = ResultsRandom[!ResultsRandom$Method == "Oracle", ]

Figure6Pre = ggplot(ResultsRandom) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure6Sen = ggplot(ResultsRandom) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure6MCC = ggplot(ResultsRandom) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid.arrange(Figure6Pre, Figure6Sen, Figure6MCC, ncol=3,
             top = textGrob("Random model", gp=gpar(fontsize=20)))

scale= 0.8

postscript("Figure6.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure6Pre, Figure6Sen, Figure6MCC, ncol=3,
             top = textGrob("Random model", gp=gpar(fontsize=20)))

dev.off()

#############################

OraclePre = ResultsHub[ResultsHub$Method == "Oracle", "Pre"]
OracleSen = ResultsHub[ResultsHub$Method == "Oracle", "Sen"]
OracleMCC = ResultsHub[ResultsHub$Method == "Oracle", "MCC"]

ResultsHub = ResultsHub[!ResultsHub$Method == "Oracle", ]

Figure7Pre = ggplot(ResultsHub) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure7Sen = ggplot(ResultsHub) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure7MCC = ggplot(ResultsHub) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid.arrange(Figure7Pre, Figure7Sen, Figure7MCC, ncol=3,
             top = textGrob("Hub model", gp=gpar(fontsize=20)))

scale= 0.8

postscript("Figure7.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure7Pre, Figure7Sen, Figure7MCC, ncol=3,
             top = textGrob("Hub model", gp=gpar(fontsize=20)))

dev.off()
