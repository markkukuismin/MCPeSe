
# 08.05.2020

library(ggplot2)
library(reshape)
library(grid)
library(gridExtra)

# Read data in

ResultsBand = read.table("Results/band_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)
ResultsScaleFree = read.table("Results/scale-free_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)
ResultsCluster = read.table("Results/cluster_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)
ResultsRandom = read.table("Results/random_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)
ResultsHub = read.table("Results/hub_n=200p=500_Class.res.txt", header=T, stringsAsFactors = F)

# Remove random results:

ResultsBand = ResultsBand[!ResultsBand$Method == "Random", ]
ResultsScaleFree = ResultsScaleFree[!ResultsScaleFree$Method == "Random", ]
ResultsCluster = ResultsCluster[!ResultsCluster$Method == "Random", ]
ResultsRandom = ResultsRandom[!ResultsRandom$Method == "Random", ]
ResultsHub = ResultsHub[!ResultsHub$Method == "Random", ]

# Rename some results:

ResultsBand$Method[ResultsBand$Method == "AR"] = "A-R"
ResultsScaleFree$Method[ResultsScaleFree$Method == "AR"] = "A-R"
ResultsCluster$Method[ResultsCluster$Method == "AR"] = "A-R"
ResultsRandom$Method[ResultsRandom$Method == "AR"] = "A-R"
ResultsHub$Method[ResultsHub$Method == "AR"] = "A-R"

ResultsBand$Method[ResultsBand$Method == "MHUnifUW"] = "M-H"
ResultsScaleFree$Method[ResultsScaleFree$Method == "MHUnifUW"] = "M-H"
ResultsCluster$Method[ResultsCluster$Method == "MHUnifUW"] = "M-H"
ResultsRandom$Method[ResultsRandom$Method == "MHUnifUW"] = "M-H"
ResultsHub$Method[ResultsHub$Method == "MHUnifUW"] = "M-H"

str(ResultsBand)

#############################

# Plot boxplots

# Band model

OraclePre = ResultsBand[ResultsBand$Method == "Oracle", "Pre"]
OracleSen = ResultsBand[ResultsBand$Method == "Oracle", "Sen"]
OracleMCC = ResultsBand[ResultsBand$Method == "Oracle", "MCC"]

ResultsBand = ResultsBand[!ResultsBand$Method == "Oracle", ]
ResultsBand = ResultsBand[!ResultsBand$Method == "MHUnifRW", ]
ResultsBand = ResultsBand[!ResultsBand$Method == "MHGammaRW", ]
ResultsBand = ResultsBand[!ResultsBand$Method == "MHGammaUW", ]

Figure3Pre = ggplot(ResultsBand) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure3Sen = ggplot(ResultsBand) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure3MCC = ggplot(ResultsBand) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5, size=16),
        axis.title=element_text(size=14,face="bold"))


grid.arrange(Figure3Pre, Figure3Sen, Figure3MCC, ncol=3,
             top = textGrob("Band model", gp=gpar(fontsize=20)))


scale = 0.8

postscript("Figure3.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure3Pre, Figure3Sen, Figure3MCC, ncol=3,
             top = textGrob("Band model", gp=gpar(fontsize=20)))

dev.off()

#############################

# Scale-free model

OraclePre = ResultsScaleFree[ResultsScaleFree$Method == "Oracle", "Pre"]
OracleSen = ResultsScaleFree[ResultsScaleFree$Method == "Oracle", "Sen"]
OracleMCC = ResultsScaleFree[ResultsScaleFree$Method == "Oracle", "MCC"]

ResultsScaleFree = ResultsScaleFree[!ResultsScaleFree$Method == "Oracle", ]

ResultsScaleFree = ResultsScaleFree[!ResultsScaleFree$Method == "Oracle", ]
ResultsScaleFree = ResultsScaleFree[!ResultsScaleFree$Method == "MHUnifRW", ]
ResultsScaleFree = ResultsScaleFree[!ResultsScaleFree$Method == "MHGammaRW", ]
ResultsScaleFree = ResultsScaleFree[!ResultsScaleFree$Method == "MHGammaUW", ]

Figure4Pre = ggplot(ResultsScaleFree) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure4Sen = ggplot(ResultsScaleFree) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure4MCC = ggplot(ResultsScaleFree) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid.arrange(Figure4Pre, Figure4Sen, Figure4MCC, ncol=3,
             top = textGrob("Scale-free model", gp=gpar(fontsize=20)))

scale= 0.8

postscript("Figure4.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure4Pre, Figure4Sen, Figure4MCC, ncol=3,
             top = textGrob("Scale-free model", gp=gpar(fontsize=20)))

dev.off()

#############################

OraclePre = ResultsCluster[ResultsCluster$Method == "Oracle", "Pre"]
OracleSen = ResultsCluster[ResultsCluster$Method == "Oracle", "Sen"]
OracleMCC = ResultsCluster[ResultsCluster$Method == "Oracle", "MCC"]

ResultsCluster = ResultsCluster[!ResultsCluster$Method == "Oracle", ]

ResultsCluster = ResultsCluster[!ResultsCluster$Method == "Oracle", ]
ResultsCluster = ResultsCluster[!ResultsCluster$Method == "MHUnifRW", ]
ResultsCluster = ResultsCluster[!ResultsCluster$Method == "MHGammaRW", ]
ResultsCluster = ResultsCluster[!ResultsCluster$Method == "MHGammaUW", ]

Figure5Pre = ggplot(ResultsCluster) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure5Sen = ggplot(ResultsCluster) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure5MCC = ggplot(ResultsCluster) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid.arrange(Figure5Pre, Figure5Sen, Figure5MCC, ncol=3,
             top = textGrob("Cluster model", gp=gpar(fontsize=20)))

scale= 0.8

postscript("Figure5.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure5Pre, Figure5Sen, Figure5MCC, ncol=3,
             top = textGrob("Cluster model", gp=gpar(fontsize=20)))

dev.off()

#############################

OraclePre = ResultsRandom[ResultsRandom$Method == "Oracle", "Pre"]
OracleSen = ResultsRandom[ResultsRandom$Method == "Oracle", "Sen"]
OracleMCC = ResultsRandom[ResultsRandom$Method == "Oracle", "MCC"]

ResultsRandom = ResultsRandom[!ResultsRandom$Method == "Oracle", ]

ResultsRandom = ResultsRandom[!ResultsRandom$Method == "Oracle", ]
ResultsRandom = ResultsRandom[!ResultsRandom$Method == "MHUnifRW", ]
ResultsRandom = ResultsRandom[!ResultsRandom$Method == "MHGammaRW", ]
ResultsRandom = ResultsRandom[!ResultsRandom$Method == "MHGammaUW", ]

Figure6Pre = ggplot(ResultsRandom) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure6Sen = ggplot(ResultsRandom) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure6MCC = ggplot(ResultsRandom) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid.arrange(Figure6Pre, Figure6Sen, Figure6MCC, ncol=3,
             top = textGrob("Random model", gp=gpar(fontsize=20)))

scale= 0.8

postscript("Figure6.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure6Pre, Figure6Sen, Figure6MCC, ncol=3,
             top = textGrob("Random model", gp=gpar(fontsize=20)))

dev.off()

#############################

OraclePre = ResultsHub[ResultsHub$Method == "Oracle", "Pre"]
OracleSen = ResultsHub[ResultsHub$Method == "Oracle", "Sen"]
OracleMCC = ResultsHub[ResultsHub$Method == "Oracle", "MCC"]

ResultsHub = ResultsHub[!ResultsHub$Method == "Oracle", ]

ResultsHub = ResultsHub[!ResultsHub$Method == "Oracle", ]
ResultsHub = ResultsHub[!ResultsHub$Method == "MHUnifRW", ]
ResultsHub = ResultsHub[!ResultsHub$Method == "MHGammaRW", ]
ResultsHub = ResultsHub[!ResultsHub$Method == "MHGammaUW", ]

Figure7Pre = ggplot(ResultsHub) +
  geom_boxplot(aes(x=Method, y=Pre)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  #ggtitle() +
  geom_hline(yintercept=median(OraclePre), linetype="dashed", color = "red") + 
  labs(y="Pre\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure7Sen = ggplot(ResultsHub) +
  geom_boxplot(aes(x=Method, y=Sen)) +
  ylim(0, 1) +
  theme(axis.text=element_text(size=8), axis.title=element_text(size=12,face="bold"), axis.text.x=element_text(size=7),
        axis.text.y = element_text(size=7)) + 
  geom_hline(yintercept=median(OracleSen), linetype="dashed", color = "red") + 
  labs(y="Sen\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))


Figure7MCC = ggplot(ResultsHub) +
  geom_boxplot(aes(x=Method, y=MCC)) +
  ylim(0, 1) +
  theme(axis.text.x=element_text(size=7), axis.text.y = element_text(size=7)) +
  labs(x = "") + 
  geom_hline(yintercept=median(OracleMCC), linetype="dashed", color = "red") + 
  labs(y="MCC\n") +
  theme(legend.position="none") + # No legend
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid.arrange(Figure7Pre, Figure7Sen, Figure7MCC, ncol=3,
             top = textGrob("Hub model", gp=gpar(fontsize=20)))

scale= 0.8

postscript("Figure7.eps", width = 15*scale, height = 5*scale, horizontal = F)

grid.arrange(Figure7Pre, Figure7Sen, Figure7MCC, ncol=3,
             top = textGrob("Hub model", gp=gpar(fontsize=20)))

dev.off()
