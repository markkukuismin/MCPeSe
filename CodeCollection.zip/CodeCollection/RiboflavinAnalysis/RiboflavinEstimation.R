
# 08.05.2020

library(hdi)
library(huge)
library(igraph)
library(tnet)
library(ggplot2)

# Load :

source("../RFunctions/mcpese.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 94256

set.seed(seed)

##########################################################

## Load data:

#data("riboflavin")
#
#Y = riboflavin[ , -1]
#
#Y = huge.npn(Y)
#
###########################################################
#
#GlassoPath = huge(as.matrix(Y), nlambda=20, method="glasso")
#
###########################################################
#
## Choose the optimal tuning parameter value:
#
#system.time(RICSelect <- huge.select(GlassoPath, criterion = "ric"))
#
#system.time(ARSelect <- mcpese(GlassoPath, n = nrow(Y), M=10^5))
#
#system.time(MHSelect <- mcpese(GlassoPath, n = nrow(Y), method = "M-H", nSteps = 5*10^4))
#
#ARSelect$accept.rate
#
#barplot(table(ARSelect$rhos))
#
#MHSelect$accept.rate
#
#barplot(table(MHSelect$rhos))
#
#save.image("Riboflavin.RData")

load("Riboflavin.RData")

##########################################################

ARSelect$opt.rho

MHSelect$opt.rho

RICSelect$opt.lambda

##########################################################

# Plot networks:

#huge.plot(RICSelect$refit)

#title(main = "RIC")

#huge.plot(GlassoPath$path[[optARRSelambdaIndx]])

#title(main = "ARRSe")

##########################################################

GAR = graph.adjacency(GlassoPath$path[[ARSelect$opt.index]], mode="undirecte")

GMH = graph.adjacency(GlassoPath$path[[MHSelect$opt.index]], mode="undirecte")

GRIC = graph.adjacency(RICSelect$refit, mode="undirected")

#postscript("Figure11.eps", width = 6, height = 6, horizontal = F)

#plot(GAR, main="Riboflavin (AR)", vertex.color="white", vertex.label=NA,
#     vertex.label.cex=0.5, vertex.size=4, edge.color="black", vertex.label.color="black")

# vertex.label=colnames(Y)

#dev.off()

#postscript("Figure12.eps", width = 6, height = 6, horizontal = F)

#plot(GRIC, main="Riboflavin (RIC)", vertex.color="white", vertex.label=NA,
#     vertex.label.cex=0.5, vertex.size=4, edge.color="black", vertex.label.color="black")

#dev.off()

##########################################################

# Sparsity level, aka, percentage of edges proportional to the full graph

RICSelect$opt.sparsity

GlassoPath$sparsity[ARSelect$opt.index]

GlassoPath$sparsity[MHSelect$opt.index]

p = ncol(Y)

NmbOfEdges = p*(p-1)/2

RICSelect$opt.sparsity*NmbOfEdges

GlassoPath$sparsity[ARSelect$opt.index]*NmbOfEdges

GlassoPath$sparsity[MHSelect$opt.index]*NmbOfEdges

##########################################################

# Compare centrality of the network nodes with each other:

NmbofTop = 5

Method = rep(c("A-R", "M-H", "RIC"), each=NmbofTop)

Measure = rep(c("Strength", "Closeness", "Betweenness"), each=NmbofTop*3)

Centrality = data.frame(Method = rep(Method, 3), Node = rep(NA, length(Measure)), Measure, Value = rep(0, length(Measure)))

###
# node strength, aka max node degree (max sum of absolute edge weights connected to each note)
###

V(GAR)$name = colnames(Y)

V(GMH)$name = colnames(Y)

V(GRIC)$name = colnames(Y)

# Get the hightest measures of "NmbofTop" nodes and collect results into the table "Centrality":

DummyAR = degree(GAR)[order(degree(GAR), decreasing = T)[1:NmbofTop]]/(p-1)

Centrality$Node[Centrality$Method == "A-R" & Centrality$Measure == "Strength"] = names(DummyAR)

Centrality$Value[Centrality$Method == "A-R" & Centrality$Measure == "Strength"] = as.vector(DummyAR)

#

DummyMH = degree(GMH)[order(degree(GMH), decreasing = T)[1:NmbofTop]]/(p-1)

Centrality$Node[Centrality$Method == "M-H" & Centrality$Measure == "Strength"] = names(DummyMH)

Centrality$Value[Centrality$Method == "M-H" & Centrality$Measure == "Strength"] = as.vector(DummyMH)

#

DummyRIC = degree(GRIC)[order(degree(GRIC), decreasing = T)[1:NmbofTop]]/(p-1)

Centrality$Node[Centrality$Method == "RIC" & Centrality$Measure == "Strength"] = names(DummyRIC)

Centrality$Value[Centrality$Method == "RIC" & Centrality$Measure == "Strength"] = as.vector(DummyRIC)

###
# Node closeness = the inverse of the sum of distances from one node to all other nodes
###

# Note! graphs are disconnected

# How many connected components are there?

components(GAR)$no

components(GMH)$no

components(GRIC)$no

#closeness(GAR, normalized = T)[order(closeness(GAR, normalized = T), decreasing = T)[1:NmbofTop]]

#closeness(GRIC, normalized = T)[order(closeness(GRIC, normalized = T), decreasing = T)[1:NmbofTop]]

# Use instead package "tnet":

GARDist = distances(GAR)

GMHDist = distances(GMH)

GRICDist = distances(GRIC)

#ARDist_w = closeness_w(GARDist, directed = F, gconly=F) # This is slow, let's do it faster:

GARDistInvert = 1/GARDist

diag(GARDistInvert) = 0

ARDist_w = colSums(GARDistInvert)/(p-1) # normalized closeness

#

GMHDistInvert = 1/GMHDist

diag(GMHDistInvert) = 0

MHDist_w = colSums(GMHDistInvert)/(p-1) # normalized closeness

#

GRICDistInvert = 1/GRICDist

diag(GRICDistInvert) = 0

RICDist_w = colSums(GRICDistInvert)/(p-1) # normalized closeness

#

DummyAR = ARDist_w[order(ARDist_w, decreasing = T)][1:NmbofTop]

Centrality$Node[Centrality$Method == "A-R" & Centrality$Measure == "Closeness"] = names(DummyAR)

Centrality$Value[Centrality$Method == "A-R" & Centrality$Measure == "Closeness"] = as.vector(DummyAR)

#


DummyMH = MHDist_w[order(MHDist_w, decreasing = T)][1:NmbofTop]

Centrality$Node[Centrality$Method == "M-H" & Centrality$Measure == "Closeness"] = names(DummyMH)

Centrality$Value[Centrality$Method == "M-H" & Centrality$Measure == "Closeness"] = as.vector(DummyMH)

#

DummyRIC = RICDist_w[order(RICDist_w, decreasing = T)][1:NmbofTop]

Centrality$Node[Centrality$Method == "RIC" & Centrality$Measure == "Closeness"] = names(DummyRIC)

Centrality$Value[Centrality$Method == "RIC" & Centrality$Measure == "Closeness"] = as.vector(DummyRIC)

###
# node betweenness = how ofter one node is in the shortest paths between other nodes
###

DummyAR = betweenness(GAR, normalized = T)[order(betweenness(GAR, normalized = T), decreasing = T)[1:NmbofTop]]

Centrality$Node[Centrality$Method == "A-R" & Centrality$Measure == "Betweenness"] = names(DummyAR)

Centrality$Value[Centrality$Method == "A-R" & Centrality$Measure == "Betweenness"] = as.vector(DummyAR)

#

DummyMH = betweenness(GMH, normalized = T)[order(betweenness(GMH, normalized = T), decreasing = T)[1:NmbofTop]]

Centrality$Node[Centrality$Method == "M-H" & Centrality$Measure == "Betweenness"] = names(DummyMH)

Centrality$Value[Centrality$Method == "M-H" & Centrality$Measure == "Betweenness"] = as.vector(DummyMH)

#

DummyRIC = betweenness(GRIC, normalized = T)[order(betweenness(GRIC, normalized = T), decreasing = T)[1:NmbofTop]]

Centrality$Node[Centrality$Method == "RIC" & Centrality$Measure == "Betweenness"] = names(DummyRIC)

Centrality$Value[Centrality$Method == "RIC" & Centrality$Measure == "Betweenness"] = as.vector(DummyRIC)

##########################################################

write.table(Centrality, "CentralityResults.txt", quote=F, row.names = F)

# Finally, plot the results:

Fig = ggplot(Centrality, aes(x=reorder(Node, -Value) , y=Value, fill=Method)) + 
  geom_col(position = position_dodge2(preserve = "single"), width = 0.5, colour="black") +
  facet_wrap(~Measure, scales = "free") +
  xlab("Node/Gene") +
  theme(axis.text.x = element_text(size = 4)) +
  scale_fill_manual(values=c("#C0C0C0", "#66FFFF", "#FFFFFF"))

Fig

scale = 0.8

postscript("Figure10.eps", width = 15*scale, height = 3*scale, horizontal = F)

Fig

dev.off()
