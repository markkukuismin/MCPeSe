
# 08.05.2020

library(hdi)
library(huge)
library(igraph)
library(tnet)
library(ggplot2)

# Load ARPS:

source("../RFunctions/ARPS_v2.R")

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 94256

set.seed(seed)

##########################################################

## Load data:

data("riboflavin")

Y = riboflavin[ , -1]

Y = huge.npn(Y)

##########################################################

GlassoPath = huge(as.matrix(Y), nlambda=20, method="glasso")

##########################################################

# Choose the optimal tuning parameter value:

system.time(RICSelect <- huge.select(GlassoPath, criterion = "ric"))

system.time(ARRSeSelect <- ARPS_v2(GlassoPath, n = nrow(Y), M=10^5))

system.time(MHRSeSelect <- ARPS_v2(GlassoPath, n = nrow(Y), method = "M-H", nSteps = 5*10^4))

mean(ARRSeSelect$rhos)

ARRSeSelect$accept.rate

plot(table(ARRSeSelect$rhos))

RICSelect$opt.lambda

save.image("Riboflavin.RData")

load("Riboflavin.RData")

##########################################################

d = abs(mean(ARRSeSelect$rhos) - GlassoPath$lambda)

optARRSelambdaIndx = which.min(d)[length(which.min(d))]

GlassoPath$lambda[optARRSelambdaIndx]

RICSelect$opt.lambda

##########################################################

# Plot networks:

#huge.plot(RICSelect$refit)

#title(main = "RIC")

#huge.plot(GlassoPath$path[[optARRSelambdaIndx]])

#title(main = "ARRSe")

##########################################################

GARPS = graph.adjacency(GlassoPath$path[[optARRSelambdaIndx]], mode="undirecte")

GRIC = graph.adjacency(RICSelect$refit, mode="undirected")

#postscript("Figure11.eps", width = 6, height = 6, horizontal = F)

#plot(GARPS, main="Riboflavin (ARPS)", vertex.color="white", vertex.label=NA,
#     vertex.label.cex=0.5, vertex.size=4, edge.color="black", vertex.label.color="black")

# vertex.label=colnames(Y)

#dev.off()

#postscript("Figure12.eps", width = 6, height = 6, horizontal = F)

#plot(GRIC, main="Riboflavin (RIC)", vertex.color="white", vertex.label=NA,
#     vertex.label.cex=0.5, vertex.size=4, edge.color="black", vertex.label.color="black")

#dev.off()

##########################################################

# Sparsity level, aka, percentage of edges proportional to the full graph

RICSelect$opt.sparsity

GlassoPath$sparsity[optARRSelambdaIndx]

p = ncol(Y)

NmbOfEdges = p*(p-1)/2

RICSelect$opt.sparsity*NmbOfEdges

GlassoPath$sparsity[optARRSelambdaIndx]*NmbOfEdges

##########################################################

# Compare centrality of the network nodes with each other:

NmbofTop = 5

Method = rep(c("ARPS", "RIC"), each=NmbofTop)

Measure = rep(c("Strength", "Closeness", "Betweenness"), each=NmbofTop*2)

Centrality = data.frame(Method = rep(Method, 3), Node = rep(NA, length(Measure)), Measure, Value = rep(0, length(Measure)))

###
# node strength, aka max node degree (max sum of absolute edge weights connected to each note)
###

V(GARPS)$name = colnames(Y)

V(GRIC)$name = colnames(Y)

# Get the hightest measures of "NmbofTop" nodes and collect results into the table "Centrality":

DummyARPS = degree(GARPS)[order(degree(GARPS), decreasing = T)[1:NmbofTop]]/(p-1)

Centrality$Node[Centrality$Method == "ARPS" & Centrality$Measure == "Strength"] = names(DummyARPS)

Centrality$Value[Centrality$Method == "ARPS" & Centrality$Measure == "Strength"] = as.vector(DummyARPS)

#

DummyRIC = degree(GRIC)[order(degree(GRIC), decreasing = T)[1:NmbofTop]]/(p-1)

Centrality$Node[Centrality$Method == "RIC" & Centrality$Measure == "Strength"] = names(DummyRIC)

Centrality$Value[Centrality$Method == "RIC" & Centrality$Measure == "Strength"] = as.vector(DummyRIC)

###
# Node closeness = the inverse of the sum of distances from one node to all other nodes
###

# Note! graphs are disconnected

# How many connected components are there?

components(GARPS)$no

components(GRIC)$no

#closeness(GARPS, normalized = T)[order(closeness(GARPS, normalized = T), decreasing = T)[1:NmbofTop]]

#closeness(GRIC, normalized = T)[order(closeness(GRIC, normalized = T), decreasing = T)[1:NmbofTop]]

# Use instead package "tnet":

GARPSDist = distances(GARPS)

GRICDist = distances(GRIC)

#ARPSDist_w = closeness_w(GARPSDist, directed = F, gconly=F) # This is slow, let's do it faster:

GARPSDistInvert = 1/GARPSDist

diag(GARPSDistInvert) = 0

ARPSDist_w = colSums(GARPSDistInvert)/(p-1) # normalized closeness

GRICDistInvert = 1/GRICDist

diag(GRICDistInvert) = 0

RICDist_w = colSums(GRICDistInvert)/(p-1) # normalized closeness

#

DummyARPS = ARPSDist_w[order(ARPSDist_w, decreasing = T)][1:NmbofTop]

Centrality$Node[Centrality$Method == "ARPS" & Centrality$Measure == "Closeness"] = names(DummyARPS)

Centrality$Value[Centrality$Method == "ARPS" & Centrality$Measure == "Closeness"] = as.vector(DummyARPS)

#

DummyRIC = RICDist_w[order(RICDist_w, decreasing = T)][1:NmbofTop]

Centrality$Node[Centrality$Method == "RIC" & Centrality$Measure == "Closeness"] = names(DummyRIC)

Centrality$Value[Centrality$Method == "RIC" & Centrality$Measure == "Closeness"] = as.vector(DummyRIC)

###
# node betweenness = how ofter one node is in the shortest paths between other nodes
###

DummyARPS = betweenness(GARPS, normalized = T)[order(betweenness(GARPS, normalized = T), decreasing = T)[1:NmbofTop]]

Centrality$Node[Centrality$Method == "ARPS" & Centrality$Measure == "Betweenness"] = names(DummyARPS)

Centrality$Value[Centrality$Method == "ARPS" & Centrality$Measure == "Betweenness"] = as.vector(DummyARPS)

#

DummyRIC = betweenness(GRIC, normalized = T)[order(betweenness(GRIC, normalized = T), decreasing = T)[1:NmbofTop]]

Centrality$Node[Centrality$Method == "RIC" & Centrality$Measure == "Betweenness"] = names(DummyRIC)

Centrality$Value[Centrality$Method == "RIC" & Centrality$Measure == "Betweenness"] = as.vector(DummyRIC)

##########################################################

#write.table(Centrality, "CentralityResults.txt", quote=F, row.names = F)

# Finally, plot the results:

Fig = ggplot(Centrality, aes(x=reorder(Node, -Value) , y=Value, fill=Method)) + 
  geom_col(position = position_dodge2(preserve = "single"), width = 0.5, colour="black") +
  facet_wrap(~Measure, scales = "free") +
  xlab("Node/Gene") +
  theme(axis.text.x = element_text(size = 4)) +
  scale_fill_manual(values=c("#00bfc4","#ffffff"))

Fig

scale = 0.8

postscript("Figure10.eps", width = 15*scale, height = 3*scale, horizontal = F)

Fig

dev.off()
