
# 4.11.2019

library(ggplot2)
library(reshape)
library(grid)
library(gridExtra)

source("RFunctions/grid_arrange_shared_legend.R")

# Read consistency results in

ResultsAR = read.table("Results/ARConsistency_hub_n=300p=600_Class.res.txt", header=T, stringsAsFactors = F)
ResultsMH = read.table("Results/MHConsistency_hub_n=300p=600_Class.res.txt", header=T, stringsAsFactors = F)
ResultsRIC = read.table("Results/RICConsistency_hub_n=300p=600_Class.res.txt", header=T, stringsAsFactors = F)

colnames(ResultsAR)[1] = "P"
colnames(ResultsMH)[1] = "P"
colnames(ResultsRIC)[1] = "P"

DummyVar = data.frame("Method" = rep("A-R", nrow(ResultsAR)))
ResultsAR = cbind(DummyVar, ResultsAR)

DummyVar = data.frame("Method" = rep("M-H", nrow(ResultsMH)))
ResultsMH = cbind(DummyVar, ResultsMH)

DummyVar = data.frame("Method" = rep("RIC", nrow(ResultsRIC)))
ResultsRIC = cbind(DummyVar, ResultsRIC)

ResultsARPre = ResultsAR[ , c("Method", "P", "Pre")]
ResultsMHPre = ResultsMH[ , c("Method", "P", "Pre")]
ResultsRICPre = ResultsRIC[ , c("Method", "P", "Pre")]

ResultsPre = rbind(ResultsARPre, ResultsMHPre, ResultsRICPre)

ResultsPre$P = as.character(ResultsPre$P)

##

ResultsARSen = ResultsAR[ , c("Method", "P", "Sen")]
ResultsMHSen = ResultsMH[ , c("Method", "P", "Sen")]
ResultsRICSen = ResultsRIC[ , c("Method", "P", "Sen")]

ResultsSen = rbind(ResultsARSen, ResultsMHSen, ResultsRICSen)

ResultsSen$P = as.character(ResultsSen$P)

##

ResultsARMCC = ResultsAR[ , c("Method", "P", "MCC")]
ResultsMHMCC = ResultsMH[ , c("Method", "P", "MCC")]
ResultsRICMCC = ResultsRIC[ , c("Method", "P", "MCC")]

ResultsMCC = rbind(ResultsARMCC, ResultsMHMCC, ResultsRICMCC)

ResultsMCC$P = as.character(ResultsMCC$P)

#############################

# Plot boxplots

FigurePre = ggplot(ResultsPre) +
  geom_boxplot(aes(x=P, y=Pre, fill=Method)) +
  scale_fill_manual(values=c("#C0C0C0", "#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(x = "") + 
  labs(y="Pre\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

FigureSen = ggplot(ResultsSen) +
  geom_boxplot(aes(x=P, y=Sen, fill=Method)) +
  scale_fill_manual(values=c("#C0C0C0", "#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(y="Sen\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

FigureMCC = ggplot(ResultsMCC) +
  geom_boxplot(aes(x=P, y=MCC, fill=Method)) +
  scale_fill_manual(values=c("#C0C0C0", "#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(x = "") + 
  labs(y="MCC\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid_arrange_shared_legend(FigurePre, FigureSen, FigureMCC, ncol=3,
             top = textGrob("Consistency", gp=gpar(fontsize=20)))


# Opening a (postscript) file does not work with grid_arrange_shared_legend. Export plot manually using
# the following width and height of the graphics region:

# Figure8

scale = 0.8

72*12*scale # width
72*7*scale # height
