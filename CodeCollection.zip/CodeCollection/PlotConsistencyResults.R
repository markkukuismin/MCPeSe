
# 4.11.2019

library(ggplot2)
library(reshape)
library(grid)
library(gridExtra)

source("RFunctions/grid_arrange_shared_legend.R")

# Read consistency results in

ResultsARPS = read.table("Results/ARPSConsistency_hub_n=300p=600_Class.res.txt", header=T, stringsAsFactors = F)
ResultsRIC = read.table("Results/RICConsistency_hub_n=300p=600_Class.res.txt", header=T, stringsAsFactors = F)

DummyVar = data.frame("Method" = rep("ARPS", nrow(ResultsARPS)))
ResultsARPS = cbind(DummyVar, ResultsARPS)

DummyVar = data.frame("Method" = rep("RIC", nrow(ResultsRIC)))
ResultsRIC = cbind(DummyVar, ResultsRIC)

ResultsARPSPre = ResultsARPS[ , c("Method", "p", "Pre")]
ResultsRICPre = ResultsRIC[ , c("Method", "p", "Pre")]

ResultsPre = rbind(ResultsARPSPre, ResultsRICPre)

ResultsPre$p = as.character(ResultsPre$p)

##

ResultsARPSSen = ResultsARPS[ , c("Method", "p", "Sen")]
ResultsRICSen = ResultsRIC[ , c("Method", "p", "Sen")]

ResultsSen = rbind(ResultsARPSSen, ResultsRICSen)

ResultsSen$p = as.character(ResultsSen$p)

##

ResultsARPSMCC = ResultsARPS[ , c("Method", "p", "MCC")]
ResultsRICMCC = ResultsRIC[ , c("Method", "p", "MCC")]

ResultsMCC = rbind(ResultsARPSMCC, ResultsRICMCC)

ResultsMCC$p = as.character(ResultsMCC$p)

#############################

# Plot boxplots

FigurePre = ggplot(ResultsPre) +
  geom_boxplot(aes(x=p, y=Pre, fill=Method)) +
  scale_fill_manual(values=c("#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(x = "") + 
  labs(y="Pre\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

FigureSen = ggplot(ResultsSen) +
  geom_boxplot(aes(x=p, y=Sen, fill=Method)) +
  scale_fill_manual(values=c("#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(y="Sen\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

FigureMCC = ggplot(ResultsMCC) +
  geom_boxplot(aes(x=p, y=MCC, fill=Method)) +
  scale_fill_manual(values=c("#66FFFF", "#FFFFFF")) + #boxplot colors
  ylim(0, 1) + 
  labs(x = "") + 
  labs(y="MCC\n") +
  theme(axis.text=element_text(size=8),axis.title=element_text(size=12,face="bold")) + 
  theme(plot.title = element_text(hjust = 0.5,size=16),
        axis.title=element_text(size=14,face="bold"))

grid_arrange_shared_legend(FigurePre, FigureSen, FigureMCC, ncol=3,
             top = textGrob("Consistency", gp=gpar(fontsize=20)))


# Opening a (postscript) file does not work with grid_arrange_shared_legend. Export plot manually using
# the following width and height of the graphics region:

# Figure7

scale = 0.8

72*12*scale # width
72*7*scale # height
