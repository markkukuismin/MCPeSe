
# 01.11.2019

# Compare the running times of ARPS, StARS, RIC and Bayes Glasso

library(MASS)
library(huge)
library(BayesianGLasso)

source("RFunctions/ARPS.R")

##########################################################

# Graphical model simulation:

Model = "random"

##########################################################

Dimension = c(50, 100, 150, 200, 250)

Simrounds = 10

nrho = 100

ARPSTime = matrix(0, nrow=Simrounds, ncol = 3)

colnames(ARPSTime) = c("user", "sytem", "elapsed")

GlassoTime = ARPSTime
RICTime = ARPSTime
StARSTime = ARPSTime
BGlassoTime = ARPSTime

ARPSResults = matrix(0, nrow = length(Dimension), ncol=3)

colnames(ARPSResults) = c("user", "sytem", "elapsed")

GlassoResults = ARPSResults
RICResults = ARPSResults
StARSResults = ARPSResults
BGlassoResults = ARPSResults

n = 60 # The sample size does not change although dimension changes

##########################################################

# Initialize seed number:

#seed = Sys.time()

#seed = as.integer(seed)

#seed = seed %% 100000

seed = 84144

set.seed(seed)

##########################################################

for(k in 1:length(Dimension)){
  
  p = Dimension[k]
  
  HugeData = huge.generator(n=10, d=p, graph=Model) # Just the covariance matrix corresponding to the graphical model of
  # interest is needed. Data replications are simulated later.
  
  Sigma = HugeData$sigma
  
  for(si in 1:Simrounds){
    
    Y = mvrnorm(n, rep(0,p), Sigma)
    
    # The whole time of the Glasso process:
    
    GlassoTime[si, ] = system.time(L <<- huge(Y, nlambda=nrho, method="glasso"))[-c(4,5)]
    
    ##########################################################
    
    # ARPS is running with hefty parameter values (huge number of samples to generate)
    
    # Accept-reject algorithm:
    
    ARPSTime[si, ] = system.time(ARPS(L, n=nrow(Y), M=5*10^5))[-c(4,5)]
    
    # Other methods are running with minimum parameter values:
    
    # RIC
    
    RICTime[si, ] = system.time(huge.select(L, criterion = "ric"))[-c(4,5)] # Nmb of rotations only 20
    
    # StARS
    
    StARSTime[si, ] = system.time(huge.select(L, criterion="stars"))[-c(4,5)] # Only 20 subsamples drawn
    
    # Bayes Glasso
    
    # Minimun MCMC length
    
    burnIn = 100
    MCMClength = 100
    
    BGlassoTime[si, ] = system.time(blockGLasso(Y, iterations = MCMClength, burnIn = burnIn))[-c(4,5)]
    
    ##########################################################
    
  }
  
  GlassoResults[k, ] = apply(GlassoTime, 2, mean)
  
  ARPSResults[k, ] = apply(ARPSTime, 2, mean)
  
  RICResults[k, ] = apply(RICTime, 2, mean)
  
  StARSResults[k, ] = apply(StARSTime, 2, mean)
  
  BGlassoResults[k, ] = apply(BGlassoTime, 2, mean)
  
}

#####################################################

MergedGlassoResults = data.frame("Method" = rep("Glasso", 3*length(Dimension)), "Dim" = rep(Dimension, each=3), 
                                "TimeClass" = rep(colnames(GlassoTime), length(Dimension)), "Time" = as.vector(t(GlassoResults)))

MergedARPSResults = data.frame("Method" = rep("ARPS", 3*length(Dimension)), "Dim" = rep(Dimension, each=3), 
                       "TimeClass" = rep(colnames(ARPSTime), length(Dimension)), "Time" = as.vector(t(ARPSResults)))

MergedRICResults = data.frame("Method" = rep("RIC", 3*length(Dimension)), "Dim" = rep(Dimension, each=3), 
                              "TimeClass" = rep(colnames(RICTime), length(Dimension)), "Time" = as.vector(t(RICResults)))

MergedStARSResults = data.frame("Method" = rep("StARS", 3*length(Dimension)), "Dim" = rep(Dimension, each=3), 
                             "TimeClass" = rep(colnames(StARSTime), length(Dimension)), "Time" = as.vector(t(StARSResults)))

MergedBGlassoResults = data.frame("Method" = rep("BGlasso", 3*length(Dimension)), "Dim" = rep(Dimension, each=3), 
                             "TimeClass" = rep(colnames(BGlassoTime), length(Dimension)), "Time" = as.vector(t(BGlassoResults)))


MergedResults = rbind(MergedGlassoResults, MergedARPSResults, MergedRICResults, MergedStARSResults, MergedBGlassoResults)

write.table(MergedResults, paste("Results/", "ComputationalTimeCompare.txt", sep=""), quote = F, row.names = F)

save.image("ComputationalTimes.RData")
